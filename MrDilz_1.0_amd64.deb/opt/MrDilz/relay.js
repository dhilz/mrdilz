#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
  const { execSync } = require("child_process");
  const fsPath = require("fs");
  if (!fsPath.existsSync(__dirname + "/node_modules")) {
      console.log("📦 Dependencies belum ada, menginstall...");
      execSync("npm install", { cwd: __dirname, stdio: "inherit" });
  }
}

// Load modul utama
require('dotenv').config({ path: __dirname + '/.env' });
const fs = require("fs"); // cukup sekali deklarasi
const path = require("path");
const { AutoComplete, Input } = require("enquirer");
const ethers = require("ethers");

const relayers = require("../abi/RelayerMap.json");
const abi = require("../abi/RelayerABI.json");

// === Cache file untuk token metadata ===
const cacheFile = path.join(__dirname, "tokenCache.json");
let tokenMetaCache = {};
try {
  if (fs.existsSync(cacheFile)) {
    tokenMetaCache = JSON.parse(fs.readFileSync(cacheFile));
  }
} catch (e) {
  console.error("⚠️ Failed to load token cache:", e.message);
}

function getDomainHash(name, version, chainId, verifyingContract) {
  const domainTypeHash = ethers.id(
    "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
  );
  return ethers.keccak256(
    ethers.AbiCoder.defaultAbiCoder().encode(
      ["bytes32", "bytes32", "bytes32", "uint256", "address"],
      [domainTypeHash, ethers.id(name), ethers.id(version), chainId, verifyingContract]
    )
  );
}

async function createProviderWithRetry(rpc, maxRetries = 5) {
  let attempt = 0;
  while (attempt < maxRetries) {
    try {
      const provider = new ethers.JsonRpcProvider(rpc);
      await provider.getNetwork();
      return provider;
    } catch (e) {
      console.error(`❌ RPC failed (attempt ${attempt + 1}): ${e.message}`);
      attempt++;
      if (attempt === maxRetries) throw new Error("Failed to connect to RPC after max retries");
      await new Promise((r) => setTimeout(r, 1000 * attempt));
    }
  }
}

(async () => {

  let relayerKey = process.env.RELAYER_PRIVATE_KEY || process.env.RELAYER_MNEMONIC;

  if (!relayerKey) {
    relayerKey = await new Input({
      message: "⚙️ Masukkan Executor (payer) mnemonic atau private key:",
    }).run();

    // Simpan ke .env
    const envPath = path.join(__dirname, ".env");
    let envData = "";
    if (fs.existsSync(envPath)) {
      envData = fs.readFileSync(envPath, "utf-8");
    }
    if (!envData.includes("RELAYER_PRIVATE_KEY")) {
      envData += `\nRELAYER_PRIVATE_KEY=${relayerKey}`;
    } else {
      envData = envData.replace(/RELAYER_PRIVATE_KEY=.*/, `RELAYER_PRIVATE_KEY=${relayerKey}`);
    }
    fs.writeFileSync(envPath, envData, "utf-8");

    console.log("✅ RELAYER_PRIVATE_KEY tersimpan di .env");
    process.env.RELAYER_PRIVATE_KEY = relayerKey;
  }

  // === Lanjut ke logika utama ===
  console.log("🚀 Program siap dijalankan...");

  console.log("=== 🔐 Gasless Permit Transfer By MrDilz (ERC20) ===");

  let baseSenderWallet;
  let baseExecutorWallet;

  outerLoop:
  while (true) {
    const senderInput = await new Input({ message: "🔐 Sender mnemonic or private key:" }).run();
    let executorInput = process.env.RELAYER_PRIVATE_KEY || process.env.RELAYER_MNEMONIC;

    if (!executorInput) {
      executorInput = await new Input({ message: "⚙️ Executor (payer) mnemonic or private key:" }).run();
    } else {
      console.log("⚙️ Using Executor credentials from environment variables.");
    }

    baseSenderWallet = senderInput.trim().split(" ").length >= 12
      ? ethers.Wallet.fromPhrase(senderInput)
      : new ethers.Wallet(senderInput);

    baseExecutorWallet = executorInput.trim().split(" ").length >= 12
      ? ethers.Wallet.fromPhrase(executorInput)
      : new ethers.Wallet(executorInput);

    console.log(`📟 Sender Address:    ${baseSenderWallet.address}`);
    console.log(`📅 Executor Address:  ${baseExecutorWallet.address}`);

    networkLoop:
    while (true) {
      const network = await new AutoComplete({
        name: "network",
        message: "🌐 Select target network:",
        choices: Object.keys(relayers),
      }).run();

      const info = relayers[network.toLowerCase()];
      let provider;
      try {
        provider = await createProviderWithRetry(info.rpc, 3);
      } catch (e) {
        console.error(e.message);
        return;
      }

      const senderWallet = baseSenderWallet.connect(provider);
      const executorWallet = baseExecutorWallet.connect(provider);
      const relayerAddress = info.address;
      console.log(`📨 Relayer Contract:  ${relayerAddress}`);

      const erc20ABI = [
        "function name() view returns (string)",
        "function version() view returns (string)",
        "function nonces(address) view returns (uint256)",
        "function _nonces(address) view returns (uint256)",
        "function DOMAIN_SEPARATOR() view returns (bytes32)",
        "function domainSeparator() view returns (bytes32)",
        "function balanceOf(address) view returns (uint256)",
        "function decimals() view returns (uint8)",
      ];

      tokenLoop:
      while (true) {
        const tokenAddress = await new Input({ message: "🏦 Token address (ERC20 with Permit):" }).run();
        const chainId = info.chainId;
        const tokenKey = `${chainId}:${tokenAddress.toLowerCase()}`;

        let token;
        try {
          token = new ethers.Contract(tokenAddress, erc20ABI, provider);
          await token.decimals();
        } catch (e) {
          const choice = await new AutoComplete({
            name: "errorAction",
            message: "❌ Token seems not ERC‑2612 compatible :",
            choices: [
              "1. Ganti token",
              "2. Ganti jaringan",
              "3. Keluar",
            ],
          }).run();
        
          if (choice.startsWith("1")) {
            continue tokenLoop;
          } else if (choice.startsWith("2")) {
            continue networkLoop; 
          } else {
            console.log("👋 Keluar aplikasi.");
            return;
          }
        }

        let name, version, nonce, domainSeparator, decimals;
        try {
          [name, decimals] = await Promise.all([token.name(), token.decimals()]);
          try { domainSeparator = await token.DOMAIN_SEPARATOR(); } catch { domainSeparator = await token.domainSeparator(); }
          try { nonce = await token.nonces(senderWallet.address); } catch { nonce = await token._nonces(senderWallet.address); }
        } catch (e) {
          console.error("❌ Token tidak mendukung permit:", e.message || e);
        
          const choice = await new AutoComplete({
            name: "errorToken",
            message: "Token error. Pilih aksi:",
            choices: [
              "1. Ganti token",
              "2. Ganti jaringan",
              "3. Keluar",
            ],
          }).run();
        
          if (choice.startsWith("1")) {
            continue tokenLoop; // ulang input token
          } else if (choice.startsWith("2")) {
            break networkLoop; // ganti jaringan
          } else {
            console.log("👋 Keluar aplikasi.");
            return;
          }
        }        
        // Gunakan cache jika ada dan cocok
        if (tokenMetaCache[tokenKey]) {
          const cached = tokenMetaCache[tokenKey];
          const computedCached = getDomainHash(cached.name, cached.version, chainId, tokenAddress);
          if (computedCached === domainSeparator) {
            name = cached.name;
            version = cached.version;
            console.log(`✅ Loaded cached token meta for chainId ${chainId} & token ${tokenAddress}: name "${name}", version "${version}"`);
          } else {
            console.log(`⚠️ Cached token meta tidak cocok untuk chainId ${chainId} & token ${tokenAddress}, abaikan cache.`);
          }
        }

        let amount;
        retryAmount: while (true) {
          const balance = await token.balanceOf(senderWallet.address);
          console.log(`📊 Balance: ${ethers.formatUnits(balance, decimals)} tokens`);
          if (balance === 0n) {
            console.error("❌ Balance is zero, skip.");
            continue;
          }

          const sendAll = await new AutoComplete({
            name: "sendAll",
            message: "❓ Kirim semua token?",
            choices: ["yes", "no"],
          }).run();

          if (sendAll === "yes") {
            amount = balance;
          } else {
            const amtStr = await new Input({
              message: `⚠️ Masukkan jumlah token (max ${ethers.formatUnits(balance, decimals)}):`,
            }).run();
            try {
              amount = ethers.parseUnits(amtStr, decimals);
            } catch {
              console.error("❌ Input jumlah tidak valid.");
              continue retryAmount;
            }
            if (amount > balance) {
              console.error("❌ Jumlah melebihi saldo.");
              continue retryAmount;
            }
          }

          console.log(`🧾 Domain:\n- Name: ${name}\n- Chain ID: ${chainId}\n- DOMAIN: ${domainSeparator}`);

          if (!version) {
            let versionsToTry = ["1", "2", "2.0", "2.1", "2.2", "2.5", "3", "v1", "v2", "v3", "", "0"];
            try {
              const onChainVer = await token.version();
              console.log(`ℹ️ token.version(): "${onChainVer}"`);
              if (!versionsToTry.includes(onChainVer)) versionsToTry.unshift(onChainVer);
            } catch {
              console.log("ℹ️ token.version() not implemented, trying defaults…");
            }

            for (const v of versionsToTry) {
              const computed = getDomainHash(name, v, chainId, tokenAddress);
              if (computed === domainSeparator) {
                version = v;
                console.log(`✅ Matched DOMAIN_SEPARATOR with version "${version || "[empty]"}"`);
                break;
              }
            }
          }

          if (!version) {
            console.error("❌ Tetap tidak bisa menemukan versi DOMAIN cocok walau di proxy implementation.");
            const confirmManual = await new AutoComplete({
              name: "manualInput",
              message: "🛠️ Ingin coba input manual name & version untuk DOMAIN?",
              choices: ["yes", "no"],
            }).run();

            if (confirmManual === "yes") {
              const manualName = await new Input({ message: "🔤 Masukkan token name (sesuai on-chain):" }).run();
              const manualVersion = await new Input({ message: "🔢 Masukkan token version (contoh: 1, v1, 2.0):" }).run();
              const computedManual = getDomainHash(manualName, manualVersion, chainId, tokenAddress);

              if (computedManual === domainSeparator) {
                name = manualName;
                version = manualVersion;
                console.log(`✅ DOMAIN cocok dengan input manual name "${name}" dan version "${version}"`);

                // Simpan cache
                tokenMetaCache[tokenKey] = { name, version };
                try {
                  fs.writeFileSync(cacheFile, JSON.stringify(tokenMetaCache, null, 2));
                  console.log(`💾 Cached token meta for chainId ${chainId} & token ${tokenAddress}.`);
                } catch (e) {
                  console.error("⚠️ Failed to write token cache:", e.message);
                }
              } else {
                console.error("❌ Masih tidak cocok. Cek input kamu atau token tidak dukung permit.");
                continue;
              }
            } else {
              continue;
            }
          }

          const deadline = Math.floor(Date.now() / 1000) + 3600;
          const permit = {
            owner: senderWallet.address,
            spender: relayerAddress,
            value: amount,
            nonce: Number(nonce),
            deadline,
          };

          const domain = {
            name,
            version,
            chainId,
            verifyingContract: tokenAddress,
          };

          const types = {
            Permit: [
              { name: "owner", type: "address" },
              { name: "spender", type: "address" },
              { name: "value", type: "uint256" },
              { name: "nonce", type: "uint256" },
              { name: "deadline", type: "uint256" },
            ],
          };

          console.log("📝 Signing permit…");
          const sig = await senderWallet.signTypedData(domain, types, permit);
          const { v, r, s } = ethers.Signature.from(sig);

          const relayer = new ethers.Contract(relayerAddress, abi, executorWallet);
          const txRequest = await relayer.relayWithPermit.populateTransaction(
            tokenAddress,
            senderWallet.address,
            executorWallet.address,
            amount,
            deadline,
            v,
            r,
            s
          );

          let gas;
          try {
            gas = await executorWallet.estimateGas(txRequest);
          } catch (e) {
            console.error("❌ Gagal estimasi gas:", e.reason || e.message || e);
          
            const choice = await new AutoComplete({
              name: "errorAction",
              message: "❌ Estimasi gas gagal. Pilih aksi:",
              choices: [
                "1. Ganti token",
                "2. Ganti jaringan",
                "3. Coba ulang input jumlah token",
                "4. Keluar",
              ],
            }).run();
          
            if (choice.startsWith("1")) {
              continue tokenLoop;
            } else if (choice.startsWith("2")) {
              continue networkLoop; 
            } else if (choice.startsWith("3")) {
              continue retryAmount; // ulang input jumlah token
            } else {
              console.log("👋 Keluar aplikasi.");
              return;
            }
          }          

          const feeData = await provider.getFeeData();
          const price = feeData.gasPrice || ethers.parseUnits("1", "gwei");
          const cost = gas * price;

          console.log(`⛽ Gas: ${gas}`);
          console.log(`💸 price : ${price} gwei`);
          console.log(`💸 Fee: ${ethers.formatEther(cost)} ETH`);

          const confirm = await new AutoComplete({
            name: "confirm",
            message: "❓ Continue with transaction?",
            choices: ["yes", "no"],
          }).run();

          if (confirm !== "yes") {
            console.log("❎ Cancelled.");
          } else {
            try {
              const tx = await relayer.relayWithPermit(
                tokenAddress,
                senderWallet.address,
                executorWallet.address,
                amount,
                deadline,
                v,
                r,
                s
              );
              console.log("🚀 Tx sent:", tx.hash);
              const explorer = info.explorer || "https://etherscan.io/tx/";
              console.log(`🔎 Explorer: ${explorer}${tx.hash}`);
              const receipt = await tx.wait();
              console.log("✅ Success! Block:", receipt.blockNumber);
            } catch (e) {
              console.error("❌ Gagal kirim transaksi:", e.reason || e.message || e);
              continue;
            }
          }

          // Pilihan aksi setelah transaksi
          const action = await new AutoComplete({
            name: "afterTx",
            message: "🔁 Pilih aksi selanjutnya:",
            choices: [
              "1. Ganti jaringan (wallet sama)",
              "2. Transaksi lain di jaringan yang sama (wallet sama)",
              "3. Ganti Wallet",
              "4. Keluar",
            ],
          }).run();

          if (action.startsWith("1")) {
            break tokenLoop; 
          } else if (action.startsWith("2")) {
            continue tokenLoop;
          } else if (action.startsWith("3")) {
            continue outerLoop;
          } else if (action.startsWith("4")) {
            console.log("👋 Selesai. Terima kasih!");
            return;
          }
        }
      }
    }
  }
})();
