#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
    const { execSync } = require("child_process");
    const fsPath = require("fs");
    if (!fsPath.existsSync(__dirname + "/node_modules")) {
        console.log("📦 Dependencies belum ada, menginstall...");
        execSync("npm install", { cwd: __dirname, stdio: "inherit" });
    }
}
// Load modul utama
require('dotenv').config({ path: __dirname + '/.env' });
const fs = require("fs"); // cukup sekali deklarasi
const path = require("path");
const { AutoComplete, Input } = require("enquirer");
const ethers = require("ethers");

const relayers = require("../abi/RelayerMap.json");

function isMnemonic(input) {
  return input.trim().split(/\s+/).length >= 12;
}

async function detectNameAndVersion(nft, chainId) {
  const autoNameList = [];
  try {
    const nameFromContract = await nft.name();
    if (nameFromContract) autoNameList.push(nameFromContract);
  } catch {}
  autoNameList.push("NFT", "Token", "");

  const versionCandidates = ["1", "2", "3", "4", "5", "v1", "v2", "v3", ""];

  let domainSeparator;
  try {
    domainSeparator = await nft.DOMAIN_SEPARATOR();
  } catch {}

  if (!domainSeparator) return null;

  for (const name of [...new Set(autoNameList)]) {
    for (const version of versionCandidates) {
      const domain = {
        name,
        version,
        chainId,
        verifyingContract: nft.target ?? nft.address,
      };
      const calcDomainSeparator = ethers.TypedDataEncoder.hashDomain(domain);
      if (calcDomainSeparator === domainSeparator) {
        return { name, version };
      }
    }
  }
  return null;
}

async function detectNonce(nft, tokenId, ownerAddr) {
  try {
    const pos = await nft.positions(tokenId);
    if (pos && pos.nonce !== undefined) return pos.nonce.toString();
  } catch {}
  try {
    const n = await nft.nonces(tokenId);
    if (n !== undefined) return n.toString();
  } catch {}
  try {
    const n = await nft.nonces(ownerAddr);
    if (n !== undefined) return n.toString();
  } catch {}
  for (const fn of ["nonce", "_nonce", "_nonces"]) {
    try {
      const n = await nft[fn](tokenId);
      if (n !== undefined) return n.toString();
    } catch {}
  }
  return undefined;
}

function listSafeTransferOverloads(iface) {
  return iface.fragments.filter(
    (f) =>
      f.type === "function" &&
      f.name === "safeTransferFrom" &&
      f.inputs.length > 0
  );
}

function inputParamsInteractively(inputs, overrides = {}) {
  const prompts = inputs.map(async (input) => {
    if (overrides.hasOwnProperty(input.name)) {
      return overrides[input.name];
    }
    const message = `Enter parameter "${input.name}" (${input.type}):`;
    let val = await new Input({ message }).run();
    if (
      input.type.startsWith("uint") ||
      input.type === "uint256" ||
      input.type === "uint96"
    ) {
      try {
        val = ethers.BigNumber.from(val).toString();
      } catch {}
    }
    return val;
  });
  return Promise.all(prompts);
}

async function isApprovedOrOwner(nft, tokenId, owner, operator) {
  try {
    const approvedAddr = await nft.getApproved(tokenId);
    if (approvedAddr && approvedAddr.toLowerCase() === operator.toLowerCase())
      return true;
  } catch {}
  try {
    const isAll = await nft.isApprovedForAll(owner, operator);
    if (isAll) return true;
  } catch {}
  if (owner.toLowerCase() === operator.toLowerCase()) return true;
  return false;
}

/**
 * Fungsi utama, diubah sedikit supaya bisa terima parameter default dari menu
 */
async function main({
  senderSecretParam,
  networkKeyParam,
  tokenAddressParam,
} = {}) {
  
  let relayerKey = process.env.RELAYER_PRIVATE_KEY || process.env.RELAYER_MNEMONIC;
  
    if (!relayerKey) {
      relayerKey = await new Input({
        message: "⚙️ Masukkan Executor (payer) mnemonic atau private key:",
      }).run();
  
      // Simpan ke .env
      const envPath = path.join(__dirname, ".env");
      let envData = "";
      if (fs.existsSync(envPath)) {
        envData = fs.readFileSync(envPath, "utf-8");
      }
      if (!envData.includes("RELAYER_PRIVATE_KEY")) {
        envData += `\nRELAYER_PRIVATE_KEY=${relayerKey}`;
      } else {
        envData = envData.replace(/RELAYER_PRIVATE_KEY=.*/, `RELAYER_PRIVATE_KEY=${relayerKey}`);
      }
      fs.writeFileSync(envPath, envData, "utf-8");
  
      console.log("✅ RELAYER_PRIVATE_KEY tersimpan di .env");
      process.env.RELAYER_PRIVATE_KEY = relayerKey;
    }
  
    // === Lanjut ke logika utama ===
    console.log("🚀 Program siap dijalankan...");

  console.log("=== 🔐 Gasless NFT Permit & Transfer via Relayer By Mr_Dilz===");

  // Input sender mnemonic/private key jika tidak diberikan
  const senderSecret =
    senderSecretParam ||
    (await new Input({
      message: "🔐 Sender mnemonic or private key:",
    }).run());

  // Pilih network (relayer) dengan nomor urut di depan
  const networkKeys = Object.keys(relayers);
  const networkPrompt = new AutoComplete({
    name: "network",
    message: "🌐 Select target network:",
    choices: networkKeys.map((v, i) => `${i + 1}. ${v}`),
  });
  const networkSelected = networkKeyParam
    ? networkKeys
        .find((k) => k.toLowerCase() === networkKeyParam.toLowerCase())
        ?.toLowerCase()
    : null;
  const networkKey = networkSelected
    ? networkSelected
    : await networkPrompt.run().then((val) => val.replace(/^\d+\.\s*/, ""));

  const info = relayers[networkKey.toLowerCase()];
  const provider = new ethers.JsonRpcProvider(info.rpc);

  // Baca semua file ABI, beri nomor urut juga
  const abiFiles = fs
    .readdirSync(path.join(__dirname, "abi"))
    .filter((f) => f.toLowerCase().endsWith(".json"));
  const abiPrompt = new AutoComplete({
    name: "abiFile",
    message: "📂 Select NFT ABI file:",
    choices: abiFiles.map((v, i) => `${i + 1}. ${v}`),
  });
  const abiFileName = await abiPrompt.run().then((val) =>
    val.replace(/^\d+\.\s*/, "")
  );
  const abiNFT = require(path.join(__dirname, "abi", abiFileName));

  // Input NFT contract address jika tidak diberikan
  const tokenAddress =
    tokenAddressParam ||
    (await new Input({ message: "🏦 NFT contract address:" }).run());

  // Input tokenId
  const tokenIdStr = await new Input({ message: "🎨 Token ID:" }).run();
  const tokenId = ethers.toBigInt(tokenIdStr);

  // Buat wallet sender
  const senderWallet = (isMnemonic(senderSecret)
    ? ethers.Wallet.fromPhrase(senderSecret)
    : new ethers.Wallet(senderSecret)
  ).connect(provider);

  // Ambil relayer secret dari env atau input manual
  let relayerSecret = process.env.RELAYER_PRIVATE_KEY || process.env.RELAYER_MNEMONIC;
  if (!relayerSecret) {
    relayerSecret = await new Input({
      message: "⚙️ Relayer mnemonic or private key:",
    }).run();
  } else {
    console.log("⚙️ Using relayer credentials from environment variables.");
  }
  const relayerWallet = (isMnemonic(relayerSecret)
    ? ethers.Wallet.fromPhrase(relayerSecret)
    : new ethers.Wallet(relayerSecret)
  ).connect(provider);

  // Setup relayer contract
  const relayerAddress = info.address;
  const abiRelayer = require("../abi/RelayerABI.json");
  const relayer = new ethers.Contract(relayerAddress, abiRelayer, relayerWallet);

  // Setup NFT contract
  const nft = new ethers.Contract(tokenAddress, abiNFT, provider);

  // Deteksi domain name & version
  let nftName = "NFT";
  let nftVersion = "1";
  const detected = await detectNameAndVersion(nft, info.chainId);
  if (detected) {
    nftName = detected.name;
    nftVersion = detected.version;
    console.log(
      `✅ DOMAIN_SEPARATOR matched: name="${nftName}", version="${nftVersion}"`
    );
  } else {
    console.warn("⚠️ DOMAIN_SEPARATOR match failed – fallback to manual input");
    const autoNameList = [];
    try {
      const nameFromContract = await nft.name();
      if (nameFromContract) autoNameList.push(nameFromContract);
    } catch {}
    autoNameList.push("NFT", "Token", "");
    if (autoNameList.length > 0) {
      const namePrompt = new AutoComplete({
        name: "nameFallback",
        message: "❓ Select or enter name:",
        choices: [...new Set(autoNameList)].map((v, i) => `${i + 1}. ${v}`),
        initial: `${1}. ${autoNameList[0]}`,
      });
      nftName = (await namePrompt.run()).replace(/^\d+\.\s*/, "");
    } else {
      nftName = await new Input({ message: "❓ Enter contract name manually:" }).run();
    }
    const versionCandidates = ["1", "2", "3", "4", "5", "v1", "v2", "v3", ""];
    const versionPrompt = new AutoComplete({
      name: "verFallback",
      message: "❓ Select or enter version:",
      choices: versionCandidates.map((v, i) => `${i + 1}. ${v}`),
      initial: "1",
    });
    nftVersion = (await versionPrompt.run()).replace(/^\d+\.\s*/, "");
  }

  // Deteksi nonce
  let nonce = await detectNonce(nft, tokenId, senderWallet.address);
  if (nonce === undefined) {
    const nonceStr = await new Input({ message: "❓ Enter nonce manually:" }).run();
    nonce = nonceStr;
  }
  console.log("🔢 Nonce to use:", nonce);

  // Input deadline
  const deadlineStr = await new Input({
    message: "⏳ Enter deadline (unix timestamp):",
    initial: (Math.floor(Date.now() / 1000) + 3600).toString(),
  }).run();
  const deadline = Number(deadlineStr);

  // Siapkan domain dan typed data
  const domain = {
    name: nftName,
    version: nftVersion,
    chainId: info.chainId,
    verifyingContract: tokenAddress,
  };

  const types = {
    Permit: [
      { name: "spender", type: "address" },
      { name: "tokenId", type: "uint256" },
      { name: "nonce", type: "uint256" },
      { name: "deadline", type: "uint256" },
    ],
  };

  const permitMessage = {
    spender: relayerAddress,
    tokenId,
    nonce,
    deadline,
  };

  // Cek approval dulu
  const approvedBefore = await isApprovedOrOwner(
    nft,
    tokenId,
    senderWallet.address,
    relayerAddress
  );

  let permitCalldata;
  if (!approvedBefore) {
    console.log("📝 Signing permit (spender = relayer contract)...");
    const sig = await senderWallet.signTypedData(domain, types, permitMessage);
    const { v, r, s } = ethers.Signature.from(sig);
    if (nft.interface.getFunction("permit")) {
      permitCalldata = nft.interface.encodeFunctionData("permit", [
        relayerAddress,
        tokenId,
        deadline,
        v,
        r,
        s,
      ]);
    } else if (nft.interface.getFunction("setApprovalForAll")) {
      console.log("ℹ️ Contract lacks permit(); using setApprovalForAll");
      permitCalldata = nft.interface.encodeFunctionData("setApprovalForAll", [
        relayerAddress,
        true,
      ]);
    } else {
      throw new Error("Contract has neither permit() nor setApprovalForAll()");
    }
  } else {
    console.log("✔️ Already approved, skipping permit/approval step");
    permitCalldata = null;
  }

  // Cari safeTransferFrom overloads dan beri nomor
  const safeTransferOverloads = listSafeTransferOverloads(nft.interface);
  if (safeTransferOverloads.length === 0) {
    throw new Error("No safeTransferFrom function found in ABI");
  }

  const choices = safeTransferOverloads.map((fn, idx) => {
    const inputsDesc = fn.inputs.map((inp) => `${inp.type} ${inp.name}`).join(", ");
    return {
      name: idx.toString(),
      message: `${idx + 1}. safeTransferFrom(${inputsDesc})`,
      value: idx,
    };
  });

  const transferChoicePrompt = new AutoComplete({
    name: "transferOverload",
    message: `🚚 Select safeTransferFrom overload (${safeTransferOverloads.length} found):`,
    choices,
  });
  const selectedIdx = await transferChoicePrompt.run();
  const selectedFn = safeTransferOverloads[selectedIdx];

  const overrideParams = {
    from: senderWallet.address,
    to: relayerWallet.address,
    tokenId: tokenId.toString(),
  };

  const transferParams = await inputParamsInteractively(selectedFn.inputs, overrideParams);

  const transferCalldata = nft.interface.encodeFunctionData(selectedFn.format(), transferParams);

  console.log("🔑 Sender wallet address:", senderWallet.address);
  console.log("🏦 NFT contract address:", tokenAddress);
  console.log("🔄 Relayer contract address:", relayerAddress);
  console.log("⛽ Relayer wallet address:", relayerWallet.address);
  console.log("📝 Permit calldata:", permitCalldata);
  console.log("📝 Transfer calldata:", transferCalldata);

  // Urutan mode sesuai permintaan, single di nomor 1
  const modeChoices = [
    { name: "single", message: "1. Single multicall (1 tx)" },
    { name: "separate", message: "2. Permit then transfer (2 tx)" },
  ];
  const modePrompt = new AutoComplete({
    name: "mode",
    message: "🚀 Select execution mode:",
    choices: modeChoices,
  });

  // .run() langsung mengembalikan .name, jadi tinggal pakai langsung
  const mode = await modePrompt.run();

  try {
    if (mode === "separate") {
      if (permitCalldata) {
        console.log("📤 Sending permit tx via relayer...");
        const tx1 = await relayer.executeWithSignatureCall(tokenAddress, permitCalldata);
        console.log("✅ Permit submitted:", tx1.hash);
        await tx1.wait();
      } else {
        console.log("ℹ️ Skipping permit tx since already approved");
      }
      console.log("📤 Sending transfer tx via relayer...");
      const tx2 = await relayer.executeWithSignatureCall(tokenAddress, transferCalldata);
      console.log("✅ Transfer submitted:", tx2.hash);
      const receipt2 = await tx2.wait();
      console.log("📦 Transfer mined in block", receipt2.blockNumber);
    } else if (mode === "single") {
      const calls = [];
      if (permitCalldata) calls.push(permitCalldata);
      calls.push(transferCalldata);
      const multicallCalldata = nft.interface.encodeFunctionData("multicall", [calls]);
      console.log("📤 Sending multicall (permit + transfer) via relayer...");
      const tx = await relayer.executeWithSignatureCall(tokenAddress, multicallCalldata);
      console.log("✅ Multicall (permit+transfer) submitted:", tx.hash);
      const receipt = await tx.wait();
      console.log("📦 Multicall mined in block", receipt.blockNumber);
    } else {
      throw new Error("Invalid mode selected");
    }
  } catch (e) {
    console.error("❌ Execution failed:");
    if (e.reason) console.error("Reason:", e.reason);
    if (e.data) console.error("Revert data:", e.data);
    console.error(e);
    if (e.transaction) {
      console.log("Transaction details:");
      console.log("  From:", e.transaction.from);
      console.log("  To:", e.transaction.to);
      console.log("  Data:", e.transaction.data);
      console.log("  Nonce:", e.transaction.nonce);
    }
    return false;
  }

  try {
    const newOwner = await nft.ownerOf(tokenId);
    console.log("👤 New NFT owner:", newOwner);
    if (newOwner.toLowerCase() === transferParams[1].toLowerCase()) {
      console.log("🎉 Transfer success!");
    } else {
      console.warn("⚠️ Owner mismatch – transfer may have failed.");
    }
  } catch (e) {
    console.error("❌ Could not verify new owner:", e.message);
  }

  // Kembalikan data penting untuk loop menu (supaya bisa pakai kembali tanpa input ulang)
  return {
    senderSecret,
    networkKey,
    tokenAddress,
  };
}

/**
 * Fungsi menjalankan loop menu setelah transaksi
 */
async function runApp() {
  let senderSecret = null;
  let networkKey = null;
  let tokenAddress = null;

  while (true) {
    const result = await main({
      senderSecretParam: senderSecret,
      networkKeyParam: networkKey,
      tokenAddressParam: tokenAddress,
    });

    console.log("\n=== Menu Setelah Transaksi ===");
    console.log("1. Ganti wallet");
    console.log("2. Ganti chain / contract relayer");
    console.log("3. Ganti contract address NFT");
    console.log("4. Exit");

    const choice = await new Input({ message: "Pilih menu nomor:" }).run();

    if (choice === "1") {
      senderSecret = await new Input({
        message: "🔐 Sender mnemonic or private key:",
      }).run();
    } else if (choice === "2") {
      // Tampilkan network dengan nomor
      const networkKeys = Object.keys(relayers);
      const networkPrompt = new AutoComplete({
        name: "network",
        message: "🌐 Select target network:",
        choices: networkKeys.map((v, i) => `${i + 1}. ${v}`),
      });
      const selected = await networkPrompt.run();
      networkKey = selected.replace(/^\d+\.\s*/, "").toLowerCase();
    } else if (choice === "3") {
      tokenAddress = await new Input({ message: "🏦 NFT contract address:" }).run();
    } else if (choice === "4") {
      console.log("👋 Keluar program...");
      process.exit(0);
    } else {
      console.log("Pilihan tidak valid, coba lagi.");
    }
  }
}

// Jalankan app
runApp().catch(console.error);
