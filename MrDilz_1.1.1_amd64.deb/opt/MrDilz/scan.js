#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
  const { execSync } = require("child_process");
  const fsPath = require("fs");
  if (!fsPath.existsSync(__dirname + "/node_modules")) {
      console.log("📦 Dependencies belum ada, menginstall...");
      execSync("npm install", { cwd: __dirname, stdio: "inherit" });
  }
}

// === Import Dependencies ===
const { ethers } = require('ethers');
const fetch = require('node-fetch');
const fs = require('fs').promises;
const readline = require('readline');
const https = require('https');
const path = require('path');
const Debank = require('debank-re');

// === Konfigurasi ===
const MAX_RETRY = 5;
const keepAliveAgent = new https.Agent({ keepAlive: true });

// === Prompt Setup ===
const rl = readline.createInterface({
input: process.stdin,
output: process.stdout
});
const ask = (q) => new Promise((resolve) => rl.question(q, resolve));

// === Fungsi parsing wallet dari mnemonic/privateKey ===
function parseWallet(input) {
try {
  if (input.trim().split(' ').length >= 12) {
    const wallet = ethers.Wallet.fromPhrase(input.trim());
    return { address: wallet.address, priv: wallet.privateKey };
  } else {
    const pk = input.startsWith('0x') ? input : '0x' + input;
    const wallet = new ethers.Wallet(pk);
    return { address: wallet.address, priv: wallet.privateKey };
  }
} catch {
  return null;
}
}

// === Ambil token dengan filter spam/dust + retry ===
async function fetchTokens(explorerBase, address, apiType) {
let url;
if (apiType === '2') {
  url = `${explorerBase}/api?module=account&action=tokenlist&address=${address}`;
} else {
  url = `${explorerBase}/api/v2/addresses/${address}/tokens`;
}

for (let attempt = 1; attempt <= MAX_RETRY; attempt++) {
  try {
    const res = await fetch(url, {
      agent: keepAliveAgent,
      headers: {
        'User-Agent': 'Mozilla/5.0',
        'Accept': 'application/json',
        'Accept-Language': 'en-US,en;q=0.9'
      }
    });

    if (res.status === 429) {
      const wait = 5000 * attempt;
      console.log(`[RATE LIMIT] Percobaan ${attempt}: menunggu ${wait / 1000}s`);
      await new Promise((r) => setTimeout(r, wait));
      continue;
    }

    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const json = await res.json();

    if (apiType === '2') {
      if (json.status === "1" && Array.isArray(json.result)) {
        return json.result.map(token => ({
          token: {
            address: token.contractAddress,
            name: token.name,
            symbol: token.symbol,
            decimals: token.decimals
          },
          value: token.balance
        }));
      } else {
        return [];
      }
    } else {
      return json.items || json.result || [];
    }
  } catch (err) {
    if (attempt === MAX_RETRY) throw err;
    await new Promise((r) => setTimeout(r, 1000 * attempt));
  }
}
}

// === Filter token spam/unknown/dusting + blacklist ===
function filterTokens(items) {
const blacklistWords = ['point', 'www', 'org', 'claim', 'com', 'net'];

return items
  .map((item) => {
    const token = item.token || item;
    const value = item.value || item.balance;
    const decimals = parseInt(token.decimals || '0');

    if (!token.name || !token.symbol) return null;
    if (token.symbol.length > 12 || token.name.length > 50) return null;
    if (/http/i.test(token.name + token.symbol)) return null;

    const nameSymbol = (token.name + token.symbol).toLowerCase();
    if (blacklistWords.some(word => nameSymbol.includes(word))) return null;

    const balance = parseFloat(ethers.formatUnits(value, decimals));

    return {
      name: token.name,
      symbol: token.symbol,
      balance,
      contract: token.address || token.address_hash
    };
  })
  .filter(Boolean);
}

// === Deteksi Token yang Support Permit (ERC‑20 & NFT) ===
async function supportsPermit(provider, tokenAddress) {
const abi = [
  "function DOMAIN_SEPARATOR() view returns (bytes32)",
  "function domainSeparator() view returns (bytes32)",
  "function getDomainSeparator() view returns (bytes32)",
  "function decimals() view returns (uint8)"
];

const contract = new ethers.Contract(tokenAddress, abi, provider);

try {
  await contract.DOMAIN_SEPARATOR();
  return true;
} catch {
  try {
    await contract.domainSeparator();
    return true;
  } catch {
    try {
      await contract.getDomainSeparator();
      return true;
    } catch {
      return false;
    }
  }
}
}

// === Fungsi Buat Provider yang Support HTTPS dan WSS ===
function createProvider(rpcUrl) {
return rpcUrl.startsWith('wss')
  ? new ethers.WebSocketProvider(rpcUrl)
  : new ethers.JsonRpcProvider(rpcUrl);
}

// === Inisiasi Debank ===
const debank = new Debank();

// === Fungsi ambil USD value wallet dari Debank ===
async function getWalletUsdValue(address) {
try {
  const result = await debank.get('/user', { id: address });
  return result?.user?.desc?.usd_value ?? null;
} catch {
  return null;
}
}

// === Main Function ===
const main = async () => {
const inputFile = await ask('Masukkan file input: ');
const chainName = await ask('Masukkan nama chain (misal: Gnosis): ');
const explorerBase = await ask('Masukkan URL explorer (cth: https://explorer.mantle.xyz): ');
const apiType = await ask('Pilih tipe API explorer (1=standar, 2=blockscout): ');
const rpcUrl = await ask('Masukkan RPC URL (untuk cek support permit): ');
const preCheckYn = await ask('Pre‑check aktivitas via RPC? (y/n): ');
rl.close();

const doPreCheck = preCheckYn.trim().toLowerCase() === 'y';
const provider = createProvider(rpcUrl);

const inputBase = path.basename(inputFile, path.extname(inputFile));
const outputFile = `${inputBase}_${chainName}.txt`;
const outputPermitFile = `${inputBase}_${chainName}_Permit.txt`;

const lines = (await fs.readFile(inputFile, 'utf8'))
  .split('\n')
  .map((x) => x.trim())
  .filter(Boolean);

await fs.writeFile(outputFile, '', 'utf8');
await fs.writeFile(outputPermitFile, '', 'utf8');

const results = [];

for (const lineRaw of lines) {
  const [addrPart, keyPart] = lineRaw.includes('|') ? lineRaw.split('|') : [null, lineRaw];
  const wallet = parseWallet(keyPart);
  if (!wallet) {
    console.log(`[SKIP] Format tidak valid: ${lineRaw}`);
    continue;
  }

  const address = addrPart && ethers.getAddress(addrPart) === wallet.address
    ? addrPart
    : wallet.address;
  const line = keyPart;

  try {
    if (doPreCheck) {
      const [txCount, balNative] = await Promise.all([
        provider.getTransactionCount(address),
        provider.getBalance(address)
      ]);
      if (txCount === 0 && balNative === 0n) {
        console.log(`[SKIP] ${address} tidak ada aktivitas (tx=0, saldo=0).`);
        continue;
      }
    }

    const code = await provider.getCode(address);
    const walletLabel = (code && code !== '0x') ? '🧠 CONTRACT' : '🧍 EOA';

    const rawTokens = await fetchTokens(explorerBase, address, apiType);
    const validTokens = filterTokens(rawTokens);

    if (validTokens.length === 0) {
      console.log(`[SKIP] ${address} tidak memiliki token valid.`);
      continue;
    }

    const volValue = await getWalletUsdValue(address);
    const volStr = volValue !== null ? `$${volValue.toFixed(2)}` : 'N/A';
    const combined = `[VOL: ${volStr} ${walletLabel}]`;

    const tokenStr = validTokens.map(t => `${t.symbol}: ${t.balance}`).join(', ');
    await fs.appendFile(outputFile, `${address}|${line} { ${tokenStr} } ${combined}\n`);

    // Permit list
    const permitArr = [];
    for (const t of validTokens) {
      if (await supportsPermit(provider, t.contract)) {
        permitArr.push(`${t.symbol}: ${t.balance}`);
      }
    }
    if (permitArr.length > 0) {
      await fs.appendFile(outputPermitFile, `${address}|${line} { ${permitArr.join(', ')} } ${combined}\n`);
    }

    results.push({ address, line, tokens: validTokens, vol: volValue ?? 0, label: combined });
    console.log(`[✅] ${address}: ${validTokens.length} token(s)`);
  } catch (err) {
    console.log(`[ERR] ${address}: ${err.message}`);
  }
}

console.log(`\nSelesai. File hasil: ${outputFile} & ${outputPermitFile}`);
};

main();
