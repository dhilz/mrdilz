#!/usr/bin/env node

console.log("==============================");
console.log("     MrDilz Command Help      ");
console.log("==============================\n");

const commands = {
    relay: "Jalankan relay utama",
    relaynft: "Jalankan relay untuk NFT",
    scan: "Scan data tertentu",
    hold: "Menangani proses hold",
    scan_alc: "Scan ALC",
    extract: "Ekstrak data",
    hybrid: "Hybrid process",
    hybrid2: "Hybrid process 2",
    call: "Jalankan proses call",
    call2: "Jalankan proses call 2",
    send: "Mengirim data",
    dbank: "Operasi DBank",
    dbank2: "Operasi DBank 2",
    extract_pv: "Ekstrak PV",
    executor: "Jalankan executor",
    norelay: "Non-relay operations",
    norelay2: "Non-relay operations 2",
    permit_maker: "Membuat permit"
};

console.log("Daftar command yang tersedia:\n");

for (const [cmd, desc] of Object.entries(commands)) {
    console.log(`${cmd.padEnd(15)} : ${desc}`);
}

console.log("\nCara pakai:");
console.log("1. Panggil command langsung dari terminal, contoh:");
console.log("   relay");
console.log("   scan");
console.log("2. Semua command sudah otomatis executable");
console.log("3. Pastikan Node.js sudah terinstall di sistem Anda\n");
console.log("==============================");
