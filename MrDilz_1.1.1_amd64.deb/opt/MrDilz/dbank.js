// === Import Dependencies ===
const fs = require('fs').promises;
const readline = require('readline');
const path = require('path');
const { ethers } = require('ethers');
const Debank = require('debank-re');

// === Prompt Setup ===
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});
const ask = (q) => new Promise((resolve) => rl.question(q, resolve));

// === Inisialisasi Debank ===
const debank = new Debank();

// === Parse mnemonic / private‑key menjadi wallet ===
function parseWallet(input) {
  try {
    if (input.trim().split(' ').length >= 12) {
      const w = ethers.Wallet.fromPhrase(input.trim());
      return { address: w.address, priv: w.privateKey };
    } else {
      const pk = input.startsWith('0x') ? input : '0x' + input;
      const w = new ethers.Wallet(pk);
      return { address: w.address, priv: w.privateKey };
    }
  } catch {
    return null;
  }
}

// === Ambil USD value via Debank dengan Retry ===
async function getWalletUsdValueWithRetry(address, maxRetries = 5, delayMs = 1000) {
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const res = await debank.get('/user', { id: address });
      const usd = res?.user?.desc?.usd_value ?? null;
      if (usd !== null) return usd;
    } catch (err) {
      console.log(`[RETRY ${attempt}] ${address} error: ${err.message}`);
    }
    await new Promise(res => setTimeout(res, delayMs));
  }
  return null;
}

// === MAIN ===
const main = async () => {
  // -- Loop hingga file input ditemukan --
  let inputFile = '';
  let inputPath = '';

  while (true) {
    inputFile = await ask('Masukkan nama file input (mnemonic/private key): ');
    inputPath = path.resolve(inputFile);

    try {
      await fs.access(inputPath);
      break;
    } catch {
      console.log(`[ERROR] File "${inputFile}" tidak ditemukan. Coba lagi.\n`);
    }
  }
  rl.close();

  const baseName   = path.basename(inputFile, path.extname(inputFile));
  const outputFile = `${baseName}_Dbank.txt`;

  // -- Baca file input & bersihkan duplikat baris (mnemonic/pk) --
  const rawLines = (await fs.readFile(inputPath, 'utf8'))
    .split('\n')
    .map(l => l.trim())
    .filter(Boolean);

  const seenInputs       = new Set();
  const uniqueInputs     = [];
  let dupMnemonicCount   = 0;
  let dupPrivateKeyCount = 0;

  for (const item of rawLines) {
    if (seenInputs.has(item)) {
      if (item.split(' ').length >= 12) dupMnemonicCount++;
      else                              dupPrivateKeyCount++;
      continue;
    }
    seenInputs.add(item);
    uniqueInputs.push(item);
  }

  // -- Ringkasan duplikat --
  if (dupMnemonicCount || dupPrivateKeyCount) {
    console.log(`[DUPLICATE SUMMARY] ${dupMnemonicCount} mnemonic duplikat, ${dupPrivateKeyCount} private key duplikat`);
  } else {
    console.log('[DUPLICATE SUMMARY] Tidak ada duplikat ditemukan');
  }

  // -- Timpa ulang file input dengan versi bersih (unik) --
  await fs.writeFile(inputPath, uniqueInputs.join('\n') + '\n', 'utf8');

  // -- Ambil daftar address yang sudah ada di output --
  let existingAddrs = new Set();
  const results = [];

  try {
    const existing = await fs.readFile(outputFile, 'utf8');
    const lines = existing.split('\n').map(l => l.trim()).filter(Boolean);
    for (const line of lines) {
      const [usdStr, addr, raw] = line.split('|');
      if (addr) {
        existingAddrs.add(addr);
        results.push({ usd: parseFloat(usdStr), address: addr, raw });
      }
    }
  } catch {
    // file belum ada, abaikan
  }

  // -- Proses wallet satu per satu --
  for (const raw of uniqueInputs) {
    const wallet = parseWallet(raw);
    if (!wallet) {
      console.log(`[SKIP] Gagal parse: ${raw}`);
      continue;
    }

    const { address } = wallet;

    // Cek apakah address sudah ada di results
    if (results.some(r => r.address === address)) {
      console.log(`[SKIP] ${address} sudah ada.`);
      continue;
    }

    try {
      const usd = await getWalletUsdValueWithRetry(address);
      if (usd === null) {
        console.log(`[SKIP] ${address} gagal ambil USD setelah retry.`);
        continue;
      }
      if (usd <= 0) {
        console.log(`[SKIP] ${address} saldo $0.`);
        continue;
      }

      const line = `${usd.toFixed(2)}|${address}|${raw}\n`;
      await fs.appendFile(outputFile, line, 'utf8'); // save realtime
      results.push({ usd, address, raw });

      console.log(`[✅] ${address} - $${usd.toFixed(2)}`);
    } catch (err) {
      console.log(`[ERROR] ${address}: ${err.message}`);
    }

    // Delay antar wallet biar aman dari rate limit
    await new Promise(res => setTimeout(res, 1200));
  }

  // -- Sort hasil & tulis ulang output --
  if (results.length) {
    results.sort((a, b) => b.usd - a.usd);
    const finalTxt = results
      .map(r => `${r.usd.toFixed(2)}|${r.address}|${r.raw}`)
      .join('\n') + '\n';
    await fs.writeFile(outputFile, finalTxt, 'utf8');
  }

  console.log(`\n✅ Selesai! Hasil akhir disimpan & diurutkan di: ${outputFile}`);
};

main();
