#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
    const { execSync } = require("child_process");
    const fsPath = require("fs");
    if (!fsPath.existsSync(__dirname + "/node_modules")) {
        console.log("📦 Dependencies belum ada, menginstall...");
        execSync("npm install", { cwd: __dirname, stdio: "inherit" });
    }
}

// Load modul utama
require('dotenv').config({ path: __dirname + '/.env' });

const readline = require('readline');
const fs = require('fs');
const path = require('path');

const envPath = path.join(__dirname, '.env');
const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise(resolve => rl.question(text, resolve));

async function promptEnvVar(name) {
    let current = process.env[name];
    if (current) {
        console.log(`${name} saat ini: ${current.slice(0, 6)}... (disembunyikan sisanya)`);
        const change = await question(`Apakah ingin mengganti ${name}? (y/N): `);
        if (change.trim().toLowerCase() !== 'y') {
            return current; // tetap pakai lama
        }
    }

    const newVal = await question(`Masukkan ${name}: `);
    return newVal.trim();
}

async function ensureEnvVariables() {
    let envContent = '';
    if (fs.existsSync(envPath)) {
        envContent = fs.readFileSync(envPath, 'utf-8');
    }

    const variables = ['RELAYER_PRIVATE_KEY', 'ALCHEMY_API_KEY'];
    const result = {};

    for (const name of variables) {
        const value = await promptEnvVar(name);
        result[name] = value;

        if (envContent.includes(`${name}=`)) {
            envContent = envContent.replace(new RegExp(`${name}=.*`), `${name}=${value}`);
        } else {
            envContent += `${name}=${value}\n`;
        }
    }

    fs.writeFileSync(envPath, envContent, 'utf-8');
    rl.close();

    return result;
}

async function main() {
    const { RELAYER_PRIVATE_KEY, ALCHEMY_API_KEY } = await ensureEnvVariables();

    console.log('\n✅ Semua environment variable sudah siap!');
    console.log(`RELAYER_PRIVATE_KEY: ${RELAYER_PRIVATE_KEY.slice(0, 6)}...`);
    console.log(`ALCHEMY_API_KEY: ${ALCHEMY_API_KEY.slice(0, 6)}...`);
}

main();
