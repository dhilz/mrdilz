const { ethers } = require('ethers');
const promptSync = require('prompt-sync');
const fs = require('fs');
const prompt = promptSync();

/** =========================
 *  Util: Retry Helper (RPC)
 *  ========================= */
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isRetryableError(e) {
  if (!e) return false;
  const msg = (e.message || '').toLowerCase();
  const code = (e.code || '').toString().toLowerCase();
  return (
    // Common ethers/provider/network errors
    code.includes('servererror') ||
    code.includes('timeout') ||
    code.includes('network') ||
    code.includes('etimedout') ||
    code.includes('econnreset') ||
    code.includes('econnrefused') ||
    msg.includes('timeout') ||
    msg.includes('network') ||
    msg.includes('connection') ||
    msg.includes('503') ||
    msg.includes('502') ||
    msg.includes('504')
  );
}

async function withRetry(action, { retries = 3, delayMs = 500, backoff = 2, label = 'RPC' } = {}) {
  let attempt = 0;
  let lastError;
  while (attempt <= retries) {
    try {
      return await action();
    } catch (e) {
      lastError = e;
      if (attempt === retries || !isRetryableError(e)) {
        throw e;
      }
      const wait = Math.round(delayMs * Math.pow(backoff, attempt));
      console.warn(`⚠️ ${label} gagal (attempt ${attempt + 1}/${retries + 1}): ${e.message || e}. Retry dalam ${wait}ms...`);
      await sleep(wait);
      attempt++;
    }
  }
  throw lastError;
}

async function supportsPermit(provider, tokenAddress) {
  const abi = [
    "function permit(address owner, address spender, uint256 value, uint256 deadline, uint8 v, bytes32 r, bytes32 s)",
    "function DOMAIN_SEPARATOR() view returns (bytes32)",
    "function domainSeparator() view returns (bytes32)",
    "function getDomainSeparator() view returns (bytes32)",
    "function decimals() view returns (uint8)",
    "function name() view returns (string)",
    "function version() view returns (string)",
    "function PERMIT_TYPEHASH() view returns (bytes32)" // cek PERMIT_TYPEHASH
  ];

  const contract = new ethers.Contract(tokenAddress, abi, provider);

  try {
    await withRetry(() => contract.decimals(), { label: 'decimals()' });

    if (typeof contract.permit !== "function") return { supported: false };

    let name, version, permitTypeHash = null;
    try { name = await withRetry(() => contract.name(), { label: 'name()' }); } catch { name = null; }
    try { version = await withRetry(() => contract.version(), { label: 'version()' }); } catch { version = null; }
    try { permitTypeHash = await withRetry(() => contract.PERMIT_TYPEHASH(), { label: 'PERMIT_TYPEHASH()' }); } catch { permitTypeHash = null; }

    const network = await withRetry(() => provider.getNetwork(), { label: 'getNetwork()' });
    const chainId = network.chainId;

    let domainSeparator;
    const domainFns = [
      { fn: () => contract.DOMAIN_SEPARATOR(), label: 'DOMAIN_SEPARATOR()' },
      { fn: () => contract.domainSeparator(), label: 'domainSeparator()' },
      { fn: () => contract.getDomainSeparator(), label: 'getDomainSeparator()' },
    ];
    for (const { fn, label } of domainFns) {
      try {
        domainSeparator = await withRetry(fn, { label });
        break;
      } catch {}
    }

    let computedDomainSeparator = null;
    let domainMatch = null;
    let usedVersion = version;
    let bruteForced = false;
    let alternativeDomainUsed = false;

    if (domainSeparator && name) {
      const tryCompute = (domainTypeHash, ver = null) => {
        const nameHash = ethers.keccak256(ethers.toUtf8Bytes(name));
        const versionHash = ver ? ethers.keccak256(ethers.toUtf8Bytes(ver)) : null;

        if (versionHash) {
          return ethers.keccak256(
            ethers.AbiCoder.defaultAbiCoder().encode(
              ["bytes32", "bytes32", "bytes32", "uint256", "address"],
              [domainTypeHash, nameHash, versionHash, chainId, tokenAddress]
            )
          );
        } else {
          return ethers.keccak256(
            ethers.AbiCoder.defaultAbiCoder().encode(
              ["bytes32", "bytes32", "uint256", "address"],
              [domainTypeHash, nameHash, chainId, tokenAddress]
            )
          );
        }
      };

      const standardDomainTypeHash = ethers.keccak256(
        ethers.toUtf8Bytes("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)")
      );

      if (version) {
        computedDomainSeparator = tryCompute(standardDomainTypeHash, version);
        domainMatch = domainSeparator.toLowerCase() === computedDomainSeparator.toLowerCase();
      }

      if (!domainMatch) {
        const commonVersions = ["1", "2", "1.0", "2.0", "v1", "v2"];
        for (const v of commonVersions) {
          const brute = tryCompute(standardDomainTypeHash, v);
          if (domainSeparator.toLowerCase() === brute.toLowerCase()) {
            computedDomainSeparator = brute;
            domainMatch = true;
            usedVersion = v;
            bruteForced = true;
            break;
          }
        }
      }

      if (!domainMatch) {
        const alternativeDomainTypeHash = ethers.keccak256(
          ethers.toUtf8Bytes("EIP712Domain(string name,uint256 chainId,address verifyingContract)")
        );

        const altComputed = tryCompute(alternativeDomainTypeHash);
        if (domainSeparator.toLowerCase() === altComputed.toLowerCase()) {
          computedDomainSeparator = altComputed;
          domainMatch = true;
          usedVersion = null;
          alternativeDomainUsed = true;
        }
      }
    }

    return {
      supported: true,
      domainSeparator,
      computedDomainSeparator,
      domainMatch,
      name,
      version: usedVersion,
      originalVersion: version,
      bruteForced,
      alternativeDomainUsed,
      permitTypeHash
    };
  } catch {
    return { supported: false };
  }
}

function saveTokenCache(chainId, address, name, version) {
  const filePath = './tokenCache.json';
  let cache = {};

  if (fs.existsSync(filePath)) {
    try {
      const data = fs.readFileSync(filePath, 'utf-8');
      cache = JSON.parse(data);
    } catch (e) {
      console.warn('⚠️ Gagal membaca tokenCache.json, membuat file baru.');
      cache = {};
    }
  }

  const key = `${chainId}:${address.toLowerCase()}`;
  cache[key] = { name, version };

  fs.writeFileSync(filePath, JSON.stringify(cache, null, 2), 'utf-8');
  console.log(`✅ Data token disimpan ke tokenCache.json dengan key: ${key}`);
}

async function signPermit({ wallet, tokenAddress, spender, value, deadline, provider }) {
  const abi = [
    "function nonces(address owner) view returns (uint256)",
    "function name() view returns (string)",
    "function version() view returns (string)",
    "function PERMIT_TYPEHASH() view returns (bytes32)",
    "function permit(address owner, address spender, uint256 value, uint256 deadline, uint8 v, bytes32 r, bytes32 s)"
  ];
  const contract = new ethers.Contract(tokenAddress, abi, provider);

  const nonce = await withRetry(() => contract.nonces(wallet.address), { label: 'nonces()' });

  const permitInfo = await supportsPermit(provider, tokenAddress);
  if (!permitInfo.supported) throw new Error("Token tidak support permit.");

  const net = await withRetry(() => provider.getNetwork(), { label: 'getNetwork()' });
  const domain = {
    name: permitInfo.name,
    version: permitInfo.version || "1",
    chainId: net.chainId,
    verifyingContract: tokenAddress,
  };
  if (permitInfo.alternativeDomainUsed) delete domain.version;

  const types = {
    Permit: [
      { name: "owner", type: "address" },
      { name: "spender", type: "address" },
      { name: "value", type: "uint256" },
      { name: "nonce", type: "uint256" },
      { name: "deadline", type: "uint256" }
    ]
  };

  const message = {
    owner: wallet.address,
    spender,
    value,
    nonce: nonce.toString(),
    deadline
  };

  const signature = await wallet.signTypedData(domain, types, message);
  const sig = ethers.Signature.from(signature);

  return {
    v: sig.v,
    r: sig.r,
    s: sig.s,
    owner: wallet.address,
    spender,
    value,
    deadline,
    nonce: nonce.toString(),
    usedPermitTypeHash: permitInfo.permitTypeHash || null
  };
}

async function main() {
  const rpcUrl = prompt("Masukkan RPC URL: ").trim();
  const tokenAddress = prompt("Masukkan alamat Token / NFT: ").trim();

  const provider = rpcUrl.startsWith("wss")
    ? new ethers.WebSocketProvider(rpcUrl)
    : new ethers.JsonRpcProvider(rpcUrl);

  const network = await withRetry(() => provider.getNetwork(), { label: 'getNetwork()' });
  const chainId = network.chainId;

  console.log(`\n[Cek permit pada token ${tokenAddress}]`);

  const result = await supportsPermit(provider, tokenAddress);

  if (result.supported) {
    console.log("✅ Token ini SUPPORT permit (EIP-2612).");

    if (result.domainSeparator) {
      console.log("Domain Separator (on-chain):", result.domainSeparator);
    }
    if (result.computedDomainSeparator) {
      console.log("Domain Separator (computed):", result.computedDomainSeparator);
    }

    if (result.domainMatch === true) {
      console.log("✅ Domain separator cocok dengan perhitungan EIP-2612.");
      if (result.alternativeDomainUsed) {
        console.log("⚠️ Domain separator cocok menggunakan tipe domain ALTERNATIF tanpa versi.");
      }
    } else if (result.domainMatch === false) {
      console.log("⚠️ Domain separator TIDAK cocok dengan perhitungan EIP-2612.");
      console.log("Ini bisa berarti token menggunakan implementasi permit custom atau tidak standar.");
    } else {
      console.log("⚠️ Tidak dapat memverifikasi domain separator.");
    }

    if (result.name) console.log("Name:", result.name);

    if (result.originalVersion !== result.version) {
      console.log(`⚠️ Versi dari kontrak: ${result.originalVersion}`);
      console.log(`🔍 Versi yang cocok ditemukan: ${result.version} ${result.bruteForced ? '(hasil brute force)' : ''}`);
    } else if (result.version) {
      console.log("Version:", result.version);
    }

    if (result.permitTypeHash) {
      console.log("ℹ️ Token ini punya PERMIT_TYPEHASH:", result.permitTypeHash);
    }

    const save = prompt("Mau simpan data token ini ke tokenCache.json? (y/n): ").trim().toLowerCase();
    if (save === 'y' || save === 'yes') {
      saveTokenCache(chainId, tokenAddress, result.name || "", result.version || "");
    }

    // Input private key / mnemonic dan spender
    const keyInput = prompt("Masukkan private key (0x...) atau mnemonic (12/24 kata): ").trim();
    let wallet;
    try {
      if (keyInput.split(" ").length >= 12) {
        // mengikuti kode asli Anda
        wallet = ethers.Wallet.fromMnemonic(keyInput);
      } else {
        wallet = new ethers.Wallet(keyInput);
      }
    } catch (e) {
      console.error("Error membuat wallet dari input:", e);
      process.exit(1);
    }

    console.log("Wallet address:", wallet.address);

    const spender = prompt("Masukkan alamat spender: ").trim();

    // Max approve value uint256
    const maxApprove = ethers.MaxUint256;
    const now = Math.floor(Date.now() / 1000);
    const deadlineHours = parseInt(prompt("Mau deadline berapa jam dari sekarang?: ").trim(), 10);
    const deadline = now + (deadlineHours * 3600);

    console.log(`\nMembuat signature permit untuk jumlah maksimal (${maxApprove}) dengan deadline 6 tahun ke depan (${new Date(deadline * 1000).toISOString()})`);

    try {
      const sigData = await signPermit({
        wallet,
        tokenAddress,
        spender,
        value: maxApprove,
        deadline,
        provider
      });

      console.log("\nSignature permit berhasil dibuat:");
      console.log(sigData);
    } catch (e) {
      console.error("Gagal membuat signature permit:", e);
    }

  } else {
    console.log("❌ Token ini TIDAK support permit (EIP-2612).");
  }
}

main();
