#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
  const { execSync } = require("child_process");
  const fsPath = require("fs");
  if (!fsPath.existsSync(__dirname + "/node_modules")) {
      console.log("📦 Dependencies belum ada, menginstall...");
      execSync("npm install", { cwd: __dirname, stdio: "inherit" });
  }
}
const fs = require('fs');
const path = require('path');
const { ethers, Wallet, JsonRpcProvider, parseUnits, formatUnits } = require("ethers");
const { AutoComplete, Input } = require('enquirer');

const RELAYER_FILE = require("../abi/RelayerMap.json");

async function askRpcUrl() {
  let relayers = {};
  if (fs.existsSync(RELAYER_FILE)) {
    relayers = JSON.parse(fs.readFileSync(RELAYER_FILE, 'utf-8'));
  }

  const chains = Object.keys(relayers);
  if (chains.length === 0) {
    // Kalau gak ada relayer, minta input RPC langsung
    const input = new Input({
      name: 'rpc',
      message: 'Masukkan RPC URL custom:'
    });
    const customRpc = await input.run();
    if (!customRpc.startsWith("http")) {
      console.error("❌ RPC URL tidak valid.");
      process.exit(1);
    }
    return customRpc;
  }

  // Tambahkan opsi custom di list
  const choices = [...chains, '[Custom RPC URL]'];

  const prompt = new AutoComplete({
    name: 'chain',
    message: 'Pilih jaringan RPC:',
    limit: 10,
    initial: 0,
    choices
  });

  const answer = await prompt.run();

  if (answer === '[Custom RPC URL]') {
    const input = new Input({
      name: 'rpc',
      message: 'Masukkan RPC URL custom:'
    });
    const customRpc = await input.run();
    if (!customRpc.startsWith("http")) {
      console.error("❌ RPC URL tidak valid.");
      process.exit(1);
    }
    return customRpc;
  } else {
    const rpc = relayers[answer]?.rpc;
    if (!rpc) {
      console.error(`❌ RPC untuk ${answer} tidak ditemukan.`);
      process.exit(1);
    }
    return rpc;
  }
}

const parseWallet = (input, provider) => {
  try {
    const cleaned = input.trim();
    if (cleaned.split(' ').length >= 12) {
      return Wallet.fromPhrase(cleaned).connect(provider);
    } else {
      const key = cleaned.startsWith('0x') ? cleaned : '0x' + cleaned;
      return new Wallet(key, provider);
    }
  } catch {
    return null;
  }
};

const ERC20_ABI = [
  "function balanceOf(address) view returns (uint256)",
  "function transfer(address to, uint256 amount) returns (bool)",
  "event Transfer(address indexed from, address indexed to, uint256 value)"
];

const ERC721_ABI = [
  "function balanceOf(address owner) view returns (uint256)",
  "function ownerOf(uint256 tokenId) view returns (address)",
  "function safeTransferFrom(address from, address to, uint256 tokenId)",
  "event Transfer(address indexed from, address indexed to, uint256 indexed tokenId)"
];

const log = (msg, data = {}) => {
  const ts = new Date().toISOString().replace('T', ' ').split('.')[0];
  console.log(`[${ts}] [INFO] ${msg} | Data: ${JSON.stringify(data)}`);
};

(async () => {
  // RPC URL dengan autocomplete
  const rpc = await askRpcUrl();

  // Input private key / mnemonic
  const keyOrMnemonicPrompt = new Input({
    name: 'keyOrMnemonic',
    message: 'Private key / Mnemonic:'
  });
  const keyOrMnemonic = await keyOrMnemonicPrompt.run();

  // ForwardTo dengan default address
  const forwardToPrompt = new Input({
    name: 'forwardTo',
    message: 'Alamat tujuan (wallet utama):',
    initial: '0x459dc0dCB82c7E3c791041F9cdb5F797b6459315'
  });
  const forwardTo = (await forwardToPrompt.run()).trim();

  // Minimum saldo
  const minStrPrompt = new Input({
    name: 'minStr',
    message: 'Minimum saldo untuk auto forward (ETH/MNT):',
    initial: '0.01'
  });
  const minStr = await minStrPrompt.run();

  // Token type
  const tokenTypePrompt = new Input({
    name: 'tokenType',
    message: 'Jenis token? (native / erc20 / erc721):',
    initial: 'native'
  });
  const tokenType = (await tokenTypePrompt.run()).toLowerCase();

  // Interval cek saldo (ms)
  const intervalPrompt = new Input({
    name: 'interval',
    message: 'Interval cek saldo (dalam ms):',
    initial: '3000'
  });
  const intervalStr = await intervalPrompt.run();
  const INTERVAL_MS = parseInt(intervalStr.trim()) || 3000;

  let tokenAddress = "";
  let tokenId = null;

  if (tokenType === "erc20" || tokenType === "erc721") {
    const tokenAddressPrompt = new Input({
      name: 'tokenAddress',
      message: `${tokenType.toUpperCase()} Token Address:`
    });
    tokenAddress = (await tokenAddressPrompt.run()).trim();
  }

  if (tokenType === "erc721") {
    const tokenIdPrompt = new Input({
      name: 'tokenId',
      message: 'Token ID yang ingin diforward (ERC721):'
    });
    const idStr = await tokenIdPrompt.run();
    tokenId = BigInt(idStr.trim());
  }

  const provider = new JsonRpcProvider(rpc);
  const wallet = parseWallet(keyOrMnemonic, provider);

  if (!wallet) {
    console.log("[x] Wallet tidak valid.");
    process.exit(1);
  }

  const address = await wallet.getAddress();
  const minAmount = parseUnits(minStr, 18);

  log("Monitoring dimulai", { type: tokenType.toUpperCase(), threshold: minStr });
  log("Target address", { wallet: address });
  log("Forward to", { forwardTo });

  const waitForConfirmation = async (tx) => {
    log("Menunggu konfirmasi...", { hash: tx.hash });
    await tx.wait();
    log("Transaksi terkonfirmasi", { hash: tx.hash });
  };

  const monitorERC20 = async () => {
    const token = new ethers.Contract(tokenAddress, ERC20_ABI, wallet);

    const trySend = async () => {
      try {
        const tokenBal = await token.balanceOf(address);
        const nativeBal = await provider.getBalance(address);

        if (tokenBal < minAmount) return;

        let gasLimit;
        try {
          gasLimit = await token.transfer.estimateGas(forwardTo, tokenBal);
        } catch {
          gasLimit = 60000n;
        }

        const { maxFeePerGas, maxPriorityFeePerGas, gasPrice } = await provider.getFeeData();
        const price = maxFeePerGas || gasPrice || 0n;
        const fee = gasLimit * price * 102n / 100n;

        log("Status saldo", {
          tokenBalance: formatUnits(tokenBal),
          nativeBalance: formatUnits(nativeBal),
          estimatedGasFee: formatUnits(fee),
          canForward: nativeBal >= fee
        });

        if (nativeBal < fee) return;

        const tx = await token.transfer(forwardTo, tokenBal, {
          gasLimit: gasLimit * 102n / 100n,
          maxFeePerGas,
          maxPriorityFeePerGas,
          gasPrice: !maxFeePerGas ? gasPrice : undefined
        });
        log("Token berhasil dikirim", { hash: tx.hash });
        await waitForConfirmation(tx);
      } catch (e) {
        console.log(`[!] ERC20 error: ${e.message}`);
      }
    };

    const poll = async () => {
      await trySend();
      setTimeout(poll, INTERVAL_MS);
    };
    poll();
  };

  const monitorERC721 = async () => {
    const nft = new ethers.Contract(tokenAddress, ERC721_ABI, wallet);

    const trySend = async () => {
      try {
        const owner = await nft.ownerOf(tokenId);
        if (owner.toLowerCase() !== address.toLowerCase()) return;

        let gasLimit;
        try {
          gasLimit = await nft.safeTransferFrom.estimateGas(address, forwardTo, tokenId);
        } catch {
          gasLimit = 100000n;
        }

        const { maxFeePerGas, maxPriorityFeePerGas, gasPrice } = await provider.getFeeData();
        const price = maxFeePerGas || gasPrice || 0n;
        const fee = gasLimit * price * 102n / 100n;
        const balance = await provider.getBalance(address);

        log("Status saldo", {
          nativeBalance: formatUnits(balance),
          estimatedGasFee: formatUnits(fee),
          canForward: balance >= fee
        });

        if (balance < fee) return;

        const tx = await nft.safeTransferFrom(address, forwardTo, tokenId, {
          gasLimit: gasLimit * 102n / 100n,
          maxFeePerGas,
          maxPriorityFeePerGas,
          gasPrice: !maxFeePerGas ? gasPrice : undefined
        });
        log("NFT berhasil dikirim", { hash: tx.hash });
        await waitForConfirmation(tx);
      } catch (e) {
        console.log(`[!] ERC721 error: ${e.message}`);
      }
    };

    const poll = async () => {
      await trySend();
      setTimeout(poll, INTERVAL_MS);
    };
    poll();
  };

  const monitorNative = async () => {
    const trySend = async () => {
      try {
        const balance = await provider.getBalance(address);

        let estimatedGasLimit;
        try {
          estimatedGasLimit = await wallet.estimateGas({ to: forwardTo, value: 0n });
        } catch {
          estimatedGasLimit = 21000n;
        }

        const feeData = await provider.getFeeData();
        const gasPrice = feeData.maxFeePerGas || feeData.gasPrice || 0n;
        const estimatedFee = estimatedGasLimit * gasPrice * 102n / 100n;

        log("Status saldo", {
          nativeBalance: formatUnits(balance),
          estimatedGasFee: formatUnits(estimatedFee),
          canForward: balance > estimatedFee && balance >= minAmount
        });

        if (balance <= estimatedFee || balance < minAmount) return;

        const amount = balance - estimatedFee;
        const tx = await wallet.sendTransaction({
          to: forwardTo,
          value: amount,
          gasLimit: estimatedGasLimit * 102n / 100n,
          maxFeePerGas: feeData.maxFeePerGas,
          maxPriorityFeePerGas: feeData.maxPriorityFeePerGas,
          gasPrice: !feeData.maxFeePerGas ? feeData.gasPrice : undefined
        });
        log("Native token berhasil dikirim", { hash: tx.hash });
        await waitForConfirmation(tx);
      } catch (e) {
        console.log(`[!] Native send error: ${e.message}`);
      }
    };

    const poll = async () => {
      await trySend();
      setTimeout(poll, INTERVAL_MS);
    };
    poll();
  };

  if (tokenType === "native") monitorNative();
  else if (tokenType === "erc20") monitorERC20();
  else if (tokenType === "erc721") monitorERC721();
  else console.log("[x] Jenis token tidak dikenali.");
})();
