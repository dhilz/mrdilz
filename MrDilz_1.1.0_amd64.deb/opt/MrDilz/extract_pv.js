#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
  const { execSync } = require("child_process");
  const fsPath = require("fs");
  if (!fsPath.existsSync(__dirname + "/node_modules")) {
      console.log("📦 Dependencies belum ada, menginstall...");
      execSync("npm install", { cwd: __dirname, stdio: "inherit" });
  }
}
const fs = require('fs');
const colors = require('colors');
const readlineSync = require('readline-sync');

function progressBar(percent, size = 30) {
    const filledLength = Math.round(size * percent / 100);
    const bar = '█'.repeat(filledLength) + '░'.repeat(size - filledLength);

    let coloredBar = '';

    if (percent < 30) {
        coloredBar = bar.red;
    } else if (percent < 70) {
        coloredBar = bar.yellow;
    } else {
        coloredBar = bar.green;
    }

    return `[${coloredBar}]`;
}

async function extractData() {
    try {
        // Clear the terminal screen
        process.stdout.write("\x1b[2J\x1b[0f");

        console.log('🔄 Memulai ekstraksi data...');

        const sourceFile = readlineSync.question('Masukkan nama file sumber: ');
        const delimiter = readlineSync.question('Masukkan pemisah data (contoh: "|", ",", ":") : ');
        const index = parseInt(readlineSync.question('Masukkan index data yang ingin diambil (0 untuk pertama, 1 untuk kedua, dst): '));
        const outputFile = readlineSync.question('Masukkan nama file result: ');

        // Memeriksa apakah file sumber ada
        if (!fs.existsSync(sourceFile)) {
            console.log('❌ File sumber tidak ditemukan!');
            return; // Jika file tidak ditemukan, kembali ke menu
        }

        const data = fs.readFileSync(sourceFile, 'utf-8').split('\n').filter(Boolean);
        const totalLines = data.length;
        let processed = 0;
        const results = [];

        // Proses ekstraksi data
        for (let i = 0; i < totalLines; i++) {
            const line = data[i];
            const splitData = line.split(delimiter);
            const extractedValue = splitData[index] || '';

            // Hanya simpan jika ada nilai yang diekstrak
            if (extractedValue) {
                results.push(extractedValue);
            }

            processed++;

            // Update progres bar setiap baris diproses
            const percent = (processed / totalLines) * 100;
            process.stdout.clearLine(0);
            process.stdout.cursorTo(0);
            process.stdout.write(progressBar(percent) + ` ${percent.toFixed(1)}% | ${processed}/${totalLines} data diproses`);

            // Beri waktu untuk update progress di terminal
            if (processed % 100 === 0) {
                fs.appendFileSync(outputFile, results.join('\n') + '\n');
                results.length = 0; // Kosongkan buffer hasil untuk mencegah penggunaan memori berlebih
            }
        }

        // Tulis sisa data ke file setelah loop selesai
        if (results.length > 0) {
            fs.appendFileSync(outputFile, results.join('\n') + '\n');
        }

        console.log(`\n✅ Ekstraksi selesai. Hasil disimpan di: ${outputFile}`);
    } catch (error) {
        console.error('❌ Terjadi kesalahan:', error.message);
    }
}

module.exports = extractData;

if (require.main === module) {
    extractData();
}