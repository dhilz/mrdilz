#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
  const { execSync } = require("child_process");
  const fsPath = require("fs");
  if (!fsPath.existsSync(__dirname + "/node_modules")) {
      console.log("📦 Dependencies belum ada, menginstall...");
      execSync("npm install", { cwd: __dirname, stdio: "inherit" });
  }
}
// Load modul utama
const fs = require('fs');
const path = require('path');
const { ethers } = require('ethers');
const { AutoComplete, Input } = require('enquirer');

const RELAYER_FILE = path.resolve(__dirname, './abi/RelayerMap.json');


function isValidMnemonic(mnemonic) {
  try {
    ethers.Wallet.fromPhrase(mnemonic);
    return true;
  } catch {
    return false;
  }
}

const parseWallet = (input) => {
  try {
    input = input.trim();

    if (input.split(' ').length >= 12 && isValidMnemonic(input)) {
      const wallet = ethers.Wallet.fromPhrase(input);
      return { address: wallet.address, priv: wallet.privateKey };
    }

    const cleaned = input.startsWith('0x') ? input.slice(2) : input;
    if (cleaned.length === 64 && /^[0-9a-fA-F]+$/.test(cleaned)) {
      const key = input.startsWith('0x') ? input : '0x' + input;
      const wallet = new ethers.Wallet(key);
      return { address: wallet.address, priv: wallet.privateKey };
    }

    throw new Error('Invalid wallet input');
  } catch (e) {
    console.log(`[!] Invalid wallet input: ${input}`);
    return null;
  }
};

async function pilihChain(chains) {
  const choices = [...chains, 'Manual Input RPC'];
  const prompt = new AutoComplete({
    name: 'selected',
    message: 'Pilih jaringan:',
    choices
  });

  const selected = await prompt.run();

  if (selected === 'Manual Input RPC') {
    const chainName = await inputPrompt('📌 Masukkan nama jaringan manual: ');
    const rpc = await inputPrompt('🌐 Masukkan RPC endpoint: ');
    return { selectedChain: chainName, rpc };
  }

  return { selectedChain: selected, rpc: relayers[selected]?.rpc };
}

async function inputPrompt(message) {
  const prompt = new Input({ message });
  return await prompt.run();
}

function parseLine(line) {
  const parts = line.split('|').map(s => s.trim());

  if (parts.length === 1) {
    return { rawKey: parts[0], amount: null, symbol: null, address: null };
  }

  if (parts.length === 3) {
    const amountSymbol = parts[0];
    const address = parts[1];
    const rawKey = parts[2];
    const match = amountSymbol.match(/^([\d.]+)?([a-zA-Z]+)$/);
    if (match) {
      return {
        amount: match[1] || null,
        symbol: match[2],
        address,
        rawKey
      };
    }
  }

  if (parts.length === 2) {
    return { amount: null, symbol: null, address: parts[0], rawKey: parts[1] };
  }

  return { rawKey: line, amount: null, symbol: null, address: null };
}

function parseTokenFile(filePath) {
  if (!fs.existsSync(filePath)) {
    console.error(`❌ File token ${filePath} tidak ditemukan!`);
    return [];
  }

  const lines = fs.readFileSync(filePath, 'utf-8').split('\n').map(l => l.trim()).filter(Boolean);
  const tokens = [];

  for (const line of lines) {
    const match = line.match(/^(\w+)\s*=\s*(0x[a-fA-F0-9]{40})\s+TYPE:(erc20|erc721|erc1155)\s+MIN:\s*([\d.]+)$/);
    if (match) {
      const [, symbol, tokenAddress, tokenType, minBalanceStr] = match;
      tokens.push({
        tokenAddress,
        tokenType,
        tokenId: null,
        minBalance: parseFloat(minBalanceStr),
        symbol
      });
    } else {
      console.log(`[!] Format token salah di baris: ${line}`);
    }
  }

  return tokens;
}

async function hasTransaction(provider, address, retry = 3, delayMs = 2000) {
  for (let i = 0; i < retry; i++) {
    try {
      const txCount = await provider.getTransactionCount(address);
      return txCount > 0;
    } catch (e) {
      const msg = e.reason || e.message || e.toString();
      console.error(`⚠️ Gagal cek txCount ${address}: ${msg}`);
      if (i < retry - 1) {
        console.log(`🔁 Ulangi cek txCount (${i + 1}/${retry}) dalam ${delayMs}ms...`);
        await new Promise(r => setTimeout(r, delayMs));
      }
    }
  }
  console.error(`❌ Gagal permanen cek txCount: ${address}`);
  return false;
}

async function main() {
  if (!fs.existsSync(RELAYER_FILE)) {
    console.error(`❌ File ${RELAYER_FILE} tidak ditemukan!`);
    return;
  }

  relayers = JSON.parse(fs.readFileSync(RELAYER_FILE, 'utf-8'));
  const chainKeys = Object.keys(relayers);
  if (chainKeys.length === 0) {
    console.error('❌ Tidak ada jaringan di RelayerMap.json');
    return;
  }

  const { selectedChain, rpc } = await pilihChain(chainKeys);

  if (!rpc) {
    console.error(`❌ RPC untuk ${selectedChain} tidak ditemukan`);
    return;
  }

  const provider = new ethers.JsonRpcProvider(rpc);

  const inputFile = await inputPrompt('📂 Masukkan nama file input wallet: ');
  const outputFile = await inputPrompt('📁 Masukkan nama file output: ');

  const pakaiFileToken = await inputPrompt('📂 Mau pakai file token? (y/n): ');
  let tokenConfigs = [];

  if (pakaiFileToken.toLowerCase() === 'y') {
    const tokenFile = await inputPrompt('📂 Masukkan nama file token: ');
    tokenConfigs = parseTokenFile(tokenFile);
    if (tokenConfigs.length === 0) {
      console.log('❌ Tidak ada token valid di file, keluar.');
      return;
    }
  } else {
    const tokenCountStr = await inputPrompt('🔢 Berapa jumlah token yang akan discan? ');
    const tokenCount = parseInt(tokenCountStr, 10);

    for (let i = 0; i < tokenCount; i++) {
      console.log(`\n🔎 Token ${i + 1}:`);
      const tokenAddress = await inputPrompt('   ↳ Alamat kontrak: ');
      const tokenType = (await inputPrompt('   ↳ Jenis (erc20 / erc721 / erc1155): ')).toLowerCase();
      let tokenId = null;
      if (tokenType === 'erc1155') {
        tokenId = await inputPrompt('   ↳ Token ID: ');
      }
      const minBalanceStr = await inputPrompt('   ↳ Minimum balance (contoh 0.01): ');
      const minBalance = parseFloat(minBalanceStr);

      tokenConfigs.push({ tokenAddress, tokenType, tokenId, minBalance });
    }
  }

  if (!fs.existsSync(inputFile)) {
    console.error('❌ File input tidak ditemukan!');
    return;
  }

  fs.writeFileSync(outputFile, '');

  const rawLines = fs.readFileSync(inputFile, 'utf-8').split('\n').map(l => l.trim()).filter(Boolean);

  for (const line of rawLines) {
    const { amount, symbol, address, rawKey } = parseLine(line);
    const wallet = parseWallet(rawKey);
    if (!wallet) continue;

    const addr = address || wallet.address;

    const used = await hasTransaction(provider, addr);
    if (!used) {
      console.log(`🟡 Wallet unused, dilewati: ${addr}`);
      continue;
    }
    console.log(`✅ Wallet used: ${addr}`);

    for (const { tokenAddress, tokenType, tokenId, minBalance, symbol: tokenSymbolFromFile } of tokenConfigs) {
      let abi = [];
      if (tokenType === 'erc20') {
        abi = [
          'function balanceOf(address) view returns (uint256)',
          'function decimals() view returns (uint8)',
          'function symbol() view returns (string)'
        ];
      } else if (tokenType === 'erc721') {
        abi = ['function balanceOf(address) view returns (uint256)'];
      } else if (tokenType === 'erc1155') {
        abi = ['function balanceOf(address, uint256) view returns (uint256)'];
      } else {
        console.log(`[!] Jenis token tidak valid: ${tokenType}`);
        continue;
      }

      const contract = new ethers.Contract(tokenAddress, abi, provider);
      let decimals = 0;
      let tokenSymbol = '';

      if (tokenType === 'erc20') {
        try {
          decimals = await contract.decimals();
        } catch {
          decimals = 18;
          console.log(`[!] Tidak bisa ambil decimals token ${tokenAddress}, default 18`);
        }
        try {
          tokenSymbol = await contract.symbol();
          if (!tokenSymbol) throw new Error('Symbol kosong');
        } catch {
          if (tokenSymbolFromFile) {
            tokenSymbol = tokenSymbolFromFile;
          } else {
            tokenSymbol = await inputPrompt(`⚠️ Tidak bisa ambil simbol token ${tokenAddress}, masukkan simbol token: `);
          }
        }
      }

      try {
        let rawBalance;
        if (tokenType === 'erc1155') {
          rawBalance = await contract.balanceOf(addr, tokenId);
        } else {
          rawBalance = await contract.balanceOf(addr);
        }

        const balanceFloat = tokenType === 'erc20'
          ? parseFloat(ethers.formatUnits(rawBalance, decimals))
          : Number(rawBalance);

        if (balanceFloat >= minBalance) {
          const formattedBalance = tokenType === 'erc20'
            ? ethers.formatUnits(rawBalance, decimals)
            : rawBalance.toString();

          const outSymbol = symbol || tokenSymbolFromFile || tokenSymbol || '';
          const outAmount = formattedBalance;

          console.log(`[+] ${addr} | Token: ${tokenAddress} | Balance: ${formattedBalance} ${outSymbol}`);

          const outLine = `${outAmount} ${outSymbol}|${addr}|${rawKey}`;
          fs.appendFileSync(outputFile, outLine + '\n');
        } else {
          console.log(`[-] ${addr} balance ${balanceFloat} < ${minBalance}, dilewati`);
        }
      } catch (e) {
        console.log(`[!] Error cek ${addr} terhadap token ${tokenAddress}: ${e.message}`);
      }
    }
  }

  console.log('\n✅ Selesai scan semua wallet dan token.');
}

main();
