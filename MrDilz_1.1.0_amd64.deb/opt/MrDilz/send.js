#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
    const { execSync } = require("child_process");
    const fsPath = require("fs");
    if (!fsPath.existsSync(__dirname + "/node_modules")) {
        console.log("📦 Dependencies belum ada, menginstall...");
        execSync("npm install", { cwd: __dirname, stdio: "inherit" });
    }
}

require('dotenv').config();
const { ethers } = require("ethers");
const readline = require("readline");

const PRIVATE_KEY = process.env.RELAYER_PRIVATE_KEY;
if (!PRIVATE_KEY) {
  console.error("Error: RELAYER_PRIVATE_KEY belum diset di environment variable");
  process.exit(1);
}

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function question(query) {
  return new Promise(resolve => rl.question(query, resolve));
}

function isValidDecimal(numStr) {
  return /^[0-9]*\.?[0-9]+$/.test(numStr);
}

async function main() {
  try {
    const rpcUrl = await question("Masukkan RPC URL: ");
    const provider = new ethers.JsonRpcProvider(rpcUrl);
    const wallet = new ethers.Wallet(PRIVATE_KEY, provider);

    const toAddress = await question("Masukkan alamat tujuan: ");

    // Cek apakah alamat contract atau EOA
    const code = await provider.getCode(toAddress);
    if (code !== '0x') {
      // Ini contract
      const confirm = await question(`Alamat tujuan adalah Contract. Lanjut kirim? (y/n): `);
      if (confirm.toLowerCase() !== 'y') {
        console.log("Transaksi dibatalkan oleh user.");
        rl.close();
        process.exit(0);
      }
    } else {
      console.log("Alamat tujuan adalah EOA (wallet biasa).");
    }

    const countStr = await question("Berapa kali kirim? ");
    const count = parseInt(countStr);
    if (isNaN(count) || count <= 0) {
      throw new Error("Input 'berapa kali kirim' harus angka positif");
    }

    const amountsStr = await question(
      `Masukkan jumlah per transaksi (pisahkan dengan spasi atau koma), minimal ${count} jumlah: `
    );

    const rawAmounts = amountsStr
      .split(/[ ,]+/)
      .map(a => a.trim())
      .filter(a => a.length > 0);

    if (rawAmounts.length < count) {
      throw new Error("Jumlah transaksi kurang dari 'berapa kali kirim'");
    }

    const amounts = rawAmounts.slice(0, count).map(a => {
      if (!isValidDecimal(a)) throw new Error(`Jumlah "${a}" bukan format desimal yang valid`);
      return ethers.parseEther(a);
    });

    console.log(`Mulai mengirim ${count} transaksi ke ${toAddress} tanpa tunggu konfirmasi...`);

    for (let i = 0; i < count; i++) {
      const amount = amounts[i];
      const tx = { to: toAddress, value: amount };

      const sentTx = await wallet.sendTransaction(tx);
      console.log(`Tx ${i + 1} dikirim, hash: ${sentTx.hash}`);
      // Tidak menunggu konfirmasi
    }

    console.log("Semua transaksi sudah dikirim!");
  } catch (err) {
    console.error("Error:", err.message);
  } finally {
    rl.close();
  }
}

main();
