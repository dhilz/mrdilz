#!/usr/bin/env node
require("dotenv").config();
const { Input, AutoComplete } = require("enquirer");
const ethers = require("ethers");
const fs = require("fs");
const path = require("path");

// Fungsi bantu hitung domain separator dengan name+version
function getDomainHash(name, version, chainId, verifyingContract) {
  const domainTypeHash = ethers.id(
    "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
  );
  return ethers.keccak256(
    ethers.AbiCoder.defaultAbiCoder().encode(
      ["bytes32", "bytes32", "bytes32", "uint256", "address"],
      [domainTypeHash, ethers.id(name), ethers.id(version), chainId, verifyingContract]
    )
  );
}

// Bruteforce version untuk DOMAIN_SEPARATOR agar cocok on-chain
async function detectDomainVersion(token, name, chainId, tokenAddress, domainSeparator) {
  let version;

  try {
    version = await token.version();
    console.log(`ℹ️ token.version(): "${version}"`);
  } catch {
    console.log("ℹ️ token.version() tidak ada, coba brute force versi...");
  }

  const versionsToTry = [
    version, "1", "2", "2.0", "2.1", "2.2", "2.5",
    "3", "v1", "v2", "v3", "", "0"
  ].filter(v => v !== undefined);

  for (const v of versionsToTry) {
    const computed = getDomainHash(name, v, chainId, tokenAddress);
    if (computed === domainSeparator) {
      console.log(`✅ Cocok DOMAIN_SEPARATOR dengan version "${v || '[empty]'}"`);
      return v;
    }
  }

  return null;
}

// ===== Tambahan: Penanganan token dengan PERMIT_TYPEHASH =====
async function supportsPermitTypeHash(token) {
  let permitTypeHash = null;
  try {
    permitTypeHash = await token.PERMIT_TYPEHASH();
    console.log("ℹ️ Token memiliki PERMIT_TYPEHASH:", permitTypeHash);
  } catch {
    console.log("ℹ️ Token tidak memiliki PERMIT_TYPEHASH");
  }
  return permitTypeHash;
}

// ===== Helper RPC retry =====
async function withRetry(fn, retries = 3, delayMs = 1000) {
  for (let i = 0; i <= retries; i++) {
    try {
      return await fn();
    } catch (err) {
      if (i === retries) throw err;
      console.warn(`⚠️ RPC call gagal, retry ${i + 1}/${retries} setelah ${delayMs}ms...`);
      await new Promise(res => setTimeout(res, delayMs));
    }
  }
}

(async () => {
  console.log("=== 🔐 Permit + Transfer Token Dual Support ===");

  // Input mnemonic/private key signer (bikin signature permit)
  const signerInput = await new Input({ message: "🔐 Masukkan mnemonic atau private key signer:" }).run();
  const signerWallet = signerInput.trim().split(" ").length >= 12
    ? ethers.Wallet.fromPhrase(signerInput)
    : new ethers.Wallet(signerInput);

  // Ambil relayer private key dari ENV RELAYER_PRIVATE_KEY
  const relayerPrivKey = process.env.RELAYER_PRIVATE_KEY;
  if (!relayerPrivKey) {
    console.error("❌ ENV RELAYER_PRIVATE_KEY belum di-set");
    process.exit(1);
  }
  const relayerWallet = relayerPrivKey.trim().split(" ").length >= 12
    ? ethers.Wallet.fromPhrase(relayerPrivKey)
    : new ethers.Wallet(relayerPrivKey);

  // Load relayer map
  const RELAYER_FILE = path.resolve('./abi/RelayerMap.json');
  if (!fs.existsSync(RELAYER_FILE)) {
    console.error(`❌ File ${RELAYER_FILE} tidak ditemukan!`);
    process.exit(1);
  }

  const relayers = JSON.parse(fs.readFileSync(RELAYER_FILE, 'utf-8'));
  const chainKeys = Object.keys(relayers);
  if (chainKeys.length === 0) {
    console.error('❌ Tidak ada jaringan dalam RelayerMap.json');
    process.exit(1);
  }

  const selectedChain = await new AutoComplete({
    name: 'selected',
    message: '🌐 Pilih jaringan:',
    choices: chainKeys
  }).run();

  const rpc = relayers[selectedChain]?.rpc;
  if (!rpc) {
    console.error(`❌ RPC untuk ${selectedChain} tidak ditemukan`);
    process.exit(1);
  }

  const provider = new ethers.JsonRpcProvider(rpc);

  // Hubungkan signer dan relayer dengan provider
  const signer = signerWallet.connect(provider);
  const relayer = relayerWallet.connect(provider);

  // Input token address (ERC20 dengan permit)
  const tokenAddress = await new Input({ message: "🏦 Alamat token (ERC20 with Permit):" }).run();

  // Pilih tipe permit
  const permitType = await new AutoComplete({
    message: "Pilih tipe permit:",
    choices: ["standard (EIP-2612)", "dai-style (bool allowed)"],
  }).run();

  // ABI sesuai tipe permit
  const erc20ABIStandard = [
    "function name() view returns (string)",
    "function version() view returns (string)",
    "function nonces(address) view returns (uint256)",
    "function balanceOf(address) view returns (uint256)",
    "function decimals() view returns (uint8)",
    "function DOMAIN_SEPARATOR() view returns (bytes32)",
    "function allowance(address owner, address spender) view returns (uint256)",
    "function permit(address owner,address spender,uint256 value,uint256 deadline,uint8 v,bytes32 r,bytes32 s)",
    "function transferFrom(address from, address to, uint256 amount) returns (bool)",
    "function PERMIT_TYPEHASH() view returns (bytes32)"
  ];

  const erc20ABIDai = [
    "function name() view returns (string)",
    "function version() view returns (string)",
    "function nonces(address) view returns (uint256)",
    "function balanceOf(address) view returns (uint256)",
    "function decimals() view returns (uint8)",
    "function DOMAIN_SEPARATOR() view returns (bytes32)",
    "function allowance(address owner, address spender) view returns (uint256)",
    "function permit(address holder,address spender,uint256 nonce,uint256 expiry,bool allowed,uint8 v,bytes32 r,bytes32 s)",
    "function transferFrom(address from, address to, uint256 amount) returns (bool)"
  ];

  // Buat kontrak token sesuai tipe permit
  const token = permitType.startsWith("standard")
    ? new ethers.Contract(tokenAddress, erc20ABIStandard, provider)
    : new ethers.Contract(tokenAddress, erc20ABIDai, provider);

  // Ambil info token
  const name = await withRetry(() => token.name());
  const decimals = await withRetry(() => token.decimals());

  // Coba dapatkan nonce dan domain separator
  let nonceBigInt;
  try {
    nonceBigInt = await withRetry(() => token.nonces(signerWallet.address));
  } catch {
    console.warn("⚠️ Fungsi nonces() gagal. Token kemungkinan besar tidak support permit.");
  }
  let domainSeparator;
  try {
    domainSeparator = await withRetry(() => token.DOMAIN_SEPARATOR());
  } catch {
    console.warn("⚠️ Fungsi DOMAIN_SEPARATOR() gagal. Token kemungkinan tidak support permit.");
  }

  // ===== Tambahan: Cek PERMIT_TYPEHASH =====
  const permitTypeHash = await supportsPermitTypeHash(token);

  // Cek balance token signer
  const balance = await withRetry(() => token.balanceOf(signerWallet.address));
  console.log(`📊 Balance token signer: ${ethers.formatUnits(balance, decimals)}`);

  if (balance === 0n) {
    console.error("❌ Balance token signer nol, keluar.");
    process.exit(1);
  }

  // Cek saldo native signer (ETH / PLS)
  const signerNativeBalance = await withRetry(() => provider.getBalance(signerWallet.address));
  console.log(`💰 Saldo native signer: ${ethers.formatEther(signerNativeBalance)} ETH/ZKF`);

  // Input kirim semua token atau tidak
  const sendAll = await new AutoComplete({ message: "🔄 Kirim semua token?", choices: ["yes", "no"] }).run();

  let amount;
  if (sendAll === "yes") {
    amount = balance;
  } else {
    const amtStr = await new Input({ message: "💰 Masukkan jumlah token yang ingin dikirim:" }).run();
    amount = ethers.parseUnits(amtStr, decimals);
    if (amount > balance) {
      console.error("❌ Jumlah melebihi saldo token.");
      process.exit(1);
    }
  }

  // Recipient otomatis ke relayerWallet.address
  const recipient = relayerWallet.address;
  console.log(`📬 Alamat penerima otomatis ke relayer: ${recipient}`);

  // Cek allowance relayer atas token signer
  const allowance = await withRetry(() => token.allowance(signerWallet.address, relayerWallet.address));
  console.log(`🔎 Allowance relayer atas token signer: ${ethers.formatUnits(allowance, decimals)}`);

  // Estimasi gas transferFrom dan gasPrice dengan populateTransaction + estimateGas + fallback
  let gasTransferFrom;
  let gasPrice;

  try {
    const txTransferFrom = await withRetry(() => token.populateTransaction.transferFrom(signerWallet.address, recipient, amount));
    gasTransferFrom = await withRetry(() => provider.estimateGas({ ...txTransferFrom, from: relayerWallet.address }));
  } catch {
    gasTransferFrom = 21000n;
  }

  try {
    gasPrice = await withRetry(() => provider.getGasPrice());
  } catch {
    gasPrice = ethers.parseUnits("1", "gwei");
  }

  const feeBySigner = gasTransferFrom * gasPrice;

  // Jika token tidak support permit (nonce atau domainSeparator gagal)
  if ((!domainSeparator || nonceBigInt === undefined)) {
    if (signerNativeBalance >= feeBySigner) {
      console.log("🚀 Token tidak support permit, tapi signer punya cukup native. Kirim langsung transferFrom via signer...");
      const tokenWithSigner = token.connect(signer);
      const tx = await withRetry(() => tokenWithSigner.transferFrom(signerWallet.address, recipient, amount));
      console.log("📦 transferFrom tx sent by signer:", tx.hash);
      await withRetry(() => tx.wait());
      console.log("✅ Transfer berhasil langsung dari signer.");
      console.log("🎉 Selesai.");
      process.exit(0);
    } else {
      console.error("❌ Token tidak support permit dan signer tidak punya saldo native cukup.");
      process.exit(1);
    }
  }

  // Kalau support permit, deteksi versi domain
  const { chainId } = await withRetry(() => provider.getNetwork());
  let version = await detectDomainVersion(token, name, chainId, tokenAddress, domainSeparator);
  if (!version) {
    console.error("❌ Gagal temukan version DOMAIN yang cocok. Coba input manual atau cek token.");
    process.exit(1);
  }

  // Cek apakah perlu permit (allowance kurang dari amount)
  const maxUint256 = ethers.MaxUint256;

  // Deadline sekarang 1 tahun ke depan (unix timestamp)
  const now = Math.floor(Date.now() / 1000);
  const ONE_YEAR = 365 * 24 * 60 * 60;
  const deadline = now + ONE_YEAR;

  let needPermit = allowance < amount;

  if (needPermit) {
    console.log("✍️ Menandatangani permit unlimited oleh signer karena allowance tidak cukup...");

    let signature, sig, v, r, s;

    if (permitTypeHash) {
      // ===== Tambahan: Sign menggunakan PERMIT_TYPEHASH =====
      const domain = { name, version, chainId, verifyingContract: tokenAddress };
      const types = {
        Permit: [
          { name: "owner", type: "address" },
          { name: "spender", type: "address" },
          { name: "value", type: "uint256" },
          { name: "nonce", type: "uint256" },
          { name: "deadline", type: "uint256" },
        ],
      };

      const permitData = {
        owner: signerWallet.address,
        spender: relayerWallet.address,
        value: maxUint256,
        nonce: Number(nonceBigInt),
        deadline,
      };

      signature = await withRetry(() => signer.signTypedData(domain, types, permitData));
      sig = ethers.Signature.from(signature);
      v = sig.v; r = sig.r; s = sig.s;

      const tokenWithRelayer = token.connect(relayer);
      console.log("⏳ Mengirim permit (PERMIT_TYPEHASH)...");
      const txPermit = await withRetry(() => tokenWithRelayer.permit(
        signerWallet.address,
        relayerWallet.address,
        maxUint256,
        deadline,
        v, r, s
      ));
      await withRetry(() => txPermit.wait());
      console.log("✅ Permit berhasil via PERMIT_TYPEHASH.");

    } else if (permitType.startsWith("standard")) {
      const domain = { name, version, chainId, verifyingContract: tokenAddress };
      const types = {
        Permit: [
          { name: "owner", type: "address" },
          { name: "spender", type: "address" },
          { name: "value", type: "uint256" },
          { name: "nonce", type: "uint256" },
          { name: "deadline", type: "uint256" },
        ],
      };

      const permitData = {
        owner: signerWallet.address,
        spender: relayerWallet.address,
        value: maxUint256,
        nonce: Number(nonceBigInt),
        deadline,
      };

      signature = await withRetry(() => signer.signTypedData(domain, types, permitData));
      sig = ethers.Signature.from(signature);
      v = sig.v; r = sig.r; s = sig.s;

      const tokenWithRelayer = token.connect(relayer);
      console.log("⏳ Mengirim permit (standard)...");
      const txPermit = await withRetry(() => tokenWithRelayer.permit(
        signerWallet.address,
        relayerWallet.address,
        maxUint256,
        deadline,
        v, r, s
      ));
      await withRetry(() => txPermit.wait());
      console.log("✅ Permit berhasil.");

    } else {
      // DAI style permit
      const domain = { name, version, chainId, verifyingContract: tokenAddress };
      const types = {
        Permit: [
          { name: "holder", type: "address" },
          { name: "spender", type: "address" },
          { name: "nonce", type: "uint256" },
          { name: "expiry", type: "uint256" },
          { name: "allowed", type: "bool" },
        ],
      };

      const permitData = {
        holder: signerWallet.address,
        spender: relayerWallet.address,
        nonce: Number(nonceBigInt),
        expiry: deadline,
        allowed: true,
      };

      signature = await withRetry(() => signer.signTypedData(domain, types, permitData));
      sig = ethers.Signature.from(signature);
      v = sig.v; r = sig.r; s = sig.s;

      const tokenWithRelayer = token.connect(relayer);
      console.log("⏳ Mengirim permit (DAI style)...");
      const txPermit = await withRetry(() => tokenWithRelayer.permit(
        signerWallet.address,
        relayerWallet.address,
        nonceBigInt,
        deadline,
        true,
        v, r, s
      ));
      await withRetry(() => txPermit.wait());
      console.log("✅ Permit berhasil.");
    }
  } else {
    console.log("✔️ Allowance sudah cukup, skip permit.");
  }

  // Setelah permit, transferFrom token dari signer ke recipient oleh relayer
  const tokenWithRelayer = token.connect(relayer);
  console.log(`⏳ Mengirim ${ethers.formatUnits(amount, decimals)} token dari signer ke relayer...`);
  const txTransfer = await withRetry(() => tokenWithRelayer.transferFrom(signerWallet.address, recipient, amount));
  console.log("📦 transferFrom tx sent:", txTransfer.hash);
  await withRetry(() => txTransfer.wait());

  console.log("🎉 Transfer token berhasil lewat relayer dengan permit!");

})().catch(console.error);
