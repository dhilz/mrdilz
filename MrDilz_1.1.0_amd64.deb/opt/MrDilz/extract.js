#!/usr/bin/env node

// Auto install dependencies kalau belum ada
{
    const { execSync } = require("child_process");
    const fsPath = require("fs");
    if (!fsPath.existsSync(__dirname + "/node_modules")) {
        console.log("📦 Dependencies belum ada, menginstall...");
        execSync("npm install", { cwd: __dirname, stdio: "inherit" });
    }
  }
  
const fs = require('fs');
const readline = require('readline');
const path = require('path');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const prompt = q => new Promise(res => rl.question(q, res));

(async () => {
  const inputPath = await prompt('📄 Path to wallet file (e.g. Db_cronos_permit.txt): ');
  if (!fs.existsSync(inputPath)) {
    console.error('❌ File not found:', inputPath);
    rl.close();
    return;
  }

  const formatChoice = await prompt('📦 Format type? (1 = wallet{tokens}, 2 = amount|address|mnemonic, 3 = by VOL, 4 = extract debank): ');
  let format;
  if (formatChoice.trim() === '2') format = 'simple';
  else if (formatChoice.trim() === '3') format = 'vol';
  else if (formatChoice.trim() === '4') format = 'extract_debank';
  else format = 'default';

  // Variabel untuk opsi extract debank: full line atau mnemonic/private key saja
  let extractMode = 'full'; // default full line

  if (format === 'extract_debank') {
    const mode = await prompt('🔹 Extract full line atau hanya mnemonic/private key saja? (f = full, m = mnemonic/private key): ');
    if (mode.trim().toLowerCase() === 'm') extractMode = 'mnemonic_only';
  }

  let tokenKeyword = null;
  if (format === 'default') {
    tokenKeyword = await prompt('🔍 Token keyword to filter (e.g. ETH, USD): ');
  }

  const minAmountInput = await prompt('💰 Minimum amount required: ');
  const minAmount = parseFloat(minAmountInput);
  if (isNaN(minAmount)) {
    console.error('❌ Invalid number for minimum amount');
    rl.close();
    return;
  }

  const lines = fs.readFileSync(inputPath, 'utf8').split('\n').filter(Boolean);
  const seenAddresses = new Set();
  const matching = [];

  for (const line of lines) {
    if (format === 'default') {
      const match = line.match(/^([^|]+)\|([^\{]+)\{([^}]*)\}.*\[(?:USD|VOL):\s*\$([\d.]+)/i);
      if (!match) continue;

      const address = match[1].trim();
      const secret = match[2].trim();
      const tokenString = match[3].trim();
      const volValue = parseFloat(match[4]);

      if (seenAddresses.has(address.toLowerCase())) continue;

      const regex = /([\w.\-+]+)\s*:\s*([\d.eE+-]+)/g;
      const tokenMap = {};
      let t;
      while ((t = regex.exec(tokenString)) !== null) {
        const key = t[1];
        const value = parseFloat(t[2]);
        tokenMap[key] = value;
      }

      const keywordLower = tokenKeyword.toLowerCase();

      for (const [key, value] of Object.entries(tokenMap)) {
        if (
          key.toLowerCase().includes(keywordLower) &&
          typeof value === 'number' &&
          value >= minAmount
        ) {
          console.log(`✅ ${address} has ${value} ${key} [USD: $${volValue}]`);
          matching.push({ address, secret, token: key, balance: value, vol: volValue });
          seenAddresses.add(address.toLowerCase());
          break;
        }
      }
    } else if (format === 'vol') {
      const volMatch = line.match(/\[(?:USD|VOL):\s*\$([\d.]+)[^\]]*\]/i);
      if (!volMatch) continue;
      const volValue = parseFloat(volMatch[1]);
      const addrMatch = line.match(/^([^|]+)\|([^\[]+)/);
      if (!addrMatch) continue;
      const address = addrMatch[1].trim();
      const secret = addrMatch[2].trim();
      if (volValue >= minAmount && !seenAddresses.has(address.toLowerCase())) {
        matching.push({ address, secret, vol: volValue });
        seenAddresses.add(address.toLowerCase());
      }
    } else if (format === 'extract_debank') {
      // Format: USD_VALUE|ADDRESS|MNEMONIC_OR_PK
      const parts = line.split('|');
      if (parts.length < 3) continue;

      const usdValue = parseFloat(parts[0]);
      const address = parts[1].trim();
      const secret = parts.slice(2).join('|').trim();

      if (isNaN(usdValue)) continue;
      if (usdValue >= minAmount && !seenAddresses.has(address.toLowerCase())) {
        if (extractMode === 'mnemonic_only') {
          console.log(`✅ Extract mnemonic/private key only for ${address}`);
          matching.push({ secret }); // hanya secret
        } else {
          console.log(`✅ ${address} has USD $${usdValue.toFixed(2)}`);
          matching.push({ address, secret, balance: usdValue });
        }
        seenAddresses.add(address.toLowerCase());
      }
    } else {
      // simple format (amount|address|mnemonic)
      const parts = line.split('|');
      if (parts.length < 3) continue;
      const rawAmount = parseFloat(parts[0]);
      const address = parts[1].trim();
      const secret = parts.slice(2).join('|').trim();

      if (isNaN(rawAmount)) continue;
      if (rawAmount >= minAmount && !seenAddresses.has(address.toLowerCase())) {
        console.log(`✅ ${address} has ${rawAmount}`);
        matching.push({ address, secret, balance: rawAmount });
        seenAddresses.add(address.toLowerCase());
      }
    }
  }

  if (matching.length === 0) {
    console.log('⚠️ No wallets matched the filter.');
    rl.close();
    return;
  }

  if (format === 'vol') {
    matching.sort((a, b) => b.vol - a.vol);
  } else if (format === 'extract_debank' && extractMode === 'mnemonic_only') {
    // gak perlu sort
  } else {
    matching.sort((a, b) => (b.balance || 0) - (a.balance || 0));
  }

  const baseName = path.basename(inputPath, path.extname(inputPath));
  const outputName =
    format === 'default' && tokenKeyword
      ? `${baseName}_${tokenKeyword}`
      : format === 'vol'
      ? `${baseName}_VOL`
      : format === 'extract_debank'
      ? extractMode === 'mnemonic_only'
        ? `${baseName}_debank_mnemonic_only`
        : `${baseName}_debank_extracted`
      : `${baseName}_filtered`;
  const outputPath = `${outputName}.txt`;

  const outputLines = matching.map(item => {
    if (format === 'default') {
      return `${item.address}|${item.secret}|${item.token}|${item.balance} [USD: $${item.vol?.toFixed(2) ?? 0}]`;
    } else if (format === 'vol') {
      return `${item.address}|${item.secret}|VOL:${item.vol}`;
    } else if (format === 'extract_debank') {
      if (extractMode === 'mnemonic_only') {
        return `${item.secret}`;
      } else {
        return `${item.balance.toFixed(2)}|${item.address}|${item.secret}`;
      }
    } else {
      return `${item.address}|${item.secret}|${item.balance}`;
    }
  });

  fs.writeFileSync(outputPath, outputLines.join('\n'), 'utf8');
  console.log(`📁 Saved ${matching.length} unique entries to ${outputPath}`);
  rl.close();
})();
