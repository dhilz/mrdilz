// === Tetap sesuai kode asli kamu, dengan tambahan cek & simpan ALCHEMY_API_KEY di folder skrip ===

const readline = require('readline');
const fs = require('fs');
const path = require('path');
const { Wallet, ethers, HDNodeWallet } = require('ethers');
const fetch = require('node-fetch');
const dotenv = require('dotenv');
const Debank = require('debank-re');

// Tentukan path .env di folder skrip asli
const envPath = path.join(__dirname, '.env');
dotenv.config({ path: envPath });

const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
const question = (text) => new Promise(resolve => rl.question(text, resolve));

async function getAlchemyApiKey() {
  let key = process.env.ALCHEMY_API_KEY;

  if (!key) {
    key = await question('Masukkan ALCHEMY_API_KEY: ');

    let envContent = '';
    if (fs.existsSync(envPath)) {
      envContent = fs.readFileSync(envPath, 'utf-8');
    }

    if (envContent.includes('ALCHEMY_API_KEY=')) {
      envContent = envContent.replace(/ALCHEMY_API_KEY=.*/, `ALCHEMY_API_KEY=${key}`);
    } else {
      envContent += `\nALCHEMY_API_KEY=${key}\n`;
    }

    fs.writeFileSync(envPath, envContent, 'utf-8');
    console.log('[💾] ALCHEMY_API_KEY tersimpan di .env');
  }

  return key;
}

const debank = new Debank();

// Precheck aktivitas
async function precheckActivity(address, rpcProvider) {
  try {
    const [txCount, balance] = await Promise.all([
      rpcProvider.send("eth_getTransactionCount", [address, "latest"]),
      rpcProvider.send("eth_getBalance", [address, "latest"]),
    ]);
    const txNum = parseInt(txCount, 16);
    const ethBal = parseFloat(ethers.formatEther(BigInt(balance)));
    return txNum > 0 || ethBal > 0;
  } catch (err) {
    console.log(`[⚠️] Precheck gagal untuk ${address}: ${err.message}`);
    return true;
  }
}

async function fetchWithRetry(url, options, retries = 3) {
  for (let i = 0; i < retries; i++) {
    try {
      const res = await fetch(url, options);
      if (!res.ok) throw new Error(`Status ${res.status}`);
      return await res.json();
    } catch (e) {
      if (i === retries - 1) throw e;
      await new Promise(r => setTimeout(r, 1000));
    }
  }
}

async function supportsPermit(tokenAddress, permitProvider) {
  const abi = ["function DOMAIN_SEPARATOR() view returns (bytes32)"];
  try {
    const contract = new ethers.Contract(tokenAddress, abi, permitProvider);
    await contract.DOMAIN_SEPARATOR();
    return true;
  } catch {
    return false;
  }
}

async function getWalletUsdValue(address) {
  try {
    const result = await debank.get('/user', { id: address });
    return result?.user?.desc?.usd_value ?? null;
  } catch {
    return null;
  }
}

async function main() {
  const ALCHEMY_API_KEY = await getAlchemyApiKey();

  const mode = await question('Pilih mode (1=Token, 2=NFT, 3=Token+NFT): ');
  const network = await question('Masukkan network Alchemy (mis. eth-mainnet / polygon-mainnet / arb-mainnet): ');
  const permitRpcUrl = await question('Masukkan RPC URL untuk cek permit (bebas, bisa public): ');
  const inputFile = await question('Masukkan file input wallet (1 per baris): ');
  const outputFile = await question('Masukkan file output hasil: ');
  rl.close();

  const baseURL = `https://${network}.g.alchemy.com/v2/${ALCHEMY_API_KEY}`;
  const permitProvider = new ethers.JsonRpcProvider(permitRpcUrl.trim());

  // File output umum
  const outputPermitFile = outputFile.replace(/(\.txt)?$/, '_Permit.txt');
  fs.writeFileSync(outputPermitFile, '', 'utf-8');

  // File NFT hanya dibuat kalau mode NFT atau Token+NFT
  let outputNftFile, outputNftPermitFile;
  if (mode === '2' || mode === '3') {
    outputNftFile = outputFile.replace(/(\.txt)?$/, '_NFT.txt');
    outputNftPermitFile = outputFile.replace(/(\.txt)?$/, '_NFT_Permit.txt');
    fs.writeFileSync(outputNftFile, '', 'utf-8');
    fs.writeFileSync(outputNftPermitFile, '', 'utf-8');
  }

  const wallets = fs.readFileSync(inputFile, 'utf-8').split('\n').map(x => x.trim()).filter(Boolean);

  for (const w of wallets) {
    let wallet;
    try {
      wallet = w.split(' ').length >= 12
        ? HDNodeWallet.fromPhrase(w)
        : new Wallet(w.startsWith('0x') ? w : '0x' + w);
    } catch {
      console.log(`[❌] Invalid wallet: ${w}`);
      continue;
    }

    const address = wallet.address;
    const header = `${address}|${w}`;
    const lines = [`[✅] ${header}`];
    let hasBalance = false;
    const permitTokensArr = [];

    const shouldCheck = await precheckActivity(address, permitProvider);
    if (!shouldCheck) {
      console.log(`[⛔️] Lewatkan ${address} (no tx & no ETH)`);
      continue;
    }

    try {
      if (mode === '1' || mode === '3') {
        // === TOKEN SECTION ===

        const nativeRes = await fetchWithRetry(baseURL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: 1,
            jsonrpc: '2.0',
            method: 'eth_getBalance',
            params: [address, 'latest']
          })
        });

        const nativeBal = ethers.formatEther(BigInt(nativeRes.result));
        if (parseFloat(nativeBal) > 0) {
          hasBalance = true;
          lines.push(`- Native Balance: ${nativeBal}`);
        }

        const tokenRes = await fetchWithRetry(baseURL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: 1,
            jsonrpc: '2.0',
            method: 'alchemy_getTokenBalances',
            params: [address, 'erc20']
          })
        });

        const tokenBalances = tokenRes.result?.tokenBalances?.filter(t => t.tokenBalance !== '0x0') || [];

        if (tokenBalances.length > 0) {
          hasBalance = true;
          for (const token of tokenBalances) {
            const contract = token.contractAddress;

            const metaRes = await fetchWithRetry(baseURL, {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                id: 1,
                jsonrpc: '2.0',
                method: 'alchemy_getTokenMetadata',
                params: [contract]
              })
            });

            const symbol = metaRes.result?.symbol || 'UNKNOWN';
            const name = metaRes.result?.name || 'Unknown Token';

            const blacklist = ['https', '.com', '.net', 'visit', 'claim'];
            const combined = `${name} ${symbol}`.toLowerCase();
            if (blacklist.some(word => combined.includes(word))) {
              console.log(`⚠️ Skip token ${symbol || name} karena mengandung kata terlarang`);
              continue;
            }

            const decimals = parseInt(metaRes.result?.decimals || '18');
            const balance = ethers.formatUnits(BigInt(token.tokenBalance), decimals);
            const supports = await supportsPermit(contract, permitProvider);

            lines.push(`- ${name} (${symbol})`);
            lines.push(`  Balance: ${balance}`);
            lines.push(`  Permit: ${supports ? '✅' : '❌'}`);

            if (supports) {
              permitTokensArr.push({ symbol, balance });
            }
          }
        }
      }

      if (mode === '2' || mode === '3') {
        // === NFT SECTION ===

        const nftRes = await fetchWithRetry(baseURL, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            id: 1,
            jsonrpc: '2.0',
            method: 'alchemy_getNFTs',
            params: [{ owner: address }]
          })
        });

        const ownedNfts = nftRes.result?.ownedNfts || [];
        const nftPermitList = [];

        if (ownedNfts.length > 0) {
          hasBalance = true;
          lines.push(`- NFT (${ownedNfts.length} total):`);
          for (const nft of ownedNfts.slice(0, 5)) {
            const contractName = nft.contractMetadata?.name || 'Unknown';
            const tokenId = nft.id?.tokenId || '??';
            const contractAddress = nft.contract?.address || nft.contractAddress;

            const permitSupport = await supportsPermit(contractAddress, permitProvider);
            lines.push(`  - ${contractName} #${parseInt(tokenId, 16)} | Permit: ${permitSupport ? '✅' : '❌'}`);

            if (permitSupport) {
              nftPermitList.push(`${contractName} #${parseInt(tokenId, 16)}`);
            }
          }

          fs.appendFileSync(outputNftFile, `${address}|${w} [NFTs: ${ownedNfts.length}]\n`, 'utf-8');
          console.log(`[💾] Tersimpan di NFT file: ${address}`);

          if (nftPermitList.length > 0) {
            const linePermitNft = `${address}|${w} { ${nftPermitList.join(', ')} }`;
            fs.appendFileSync(outputNftPermitFile, linePermitNft + '\n', 'utf-8');
            console.log(`[💾] Tersimpan di NFT Permit file: ${address}`);
          }
        }
      }

      if (hasBalance) {
        const usdVal = await getWalletUsdValue(address);
        if (usdVal !== null) {
          lines.push(`- USD Value: $${usdVal.toFixed(2)}`);
        }

        fs.appendFileSync(outputFile, lines.join('\n') + '\n\n', 'utf-8');
        console.log(`[💾] Tersimpan: ${address}`);

        if (permitTokensArr.length > 0) {
          const permitLineTokens = permitTokensArr.map(t => `${t.symbol}: ${t.balance}`).join(', ');
          const permitLine = `${address}|${w} { ${permitLineTokens} } [VOL: ${usdVal !== null ? `$${usdVal.toFixed(2)}` : 'N/A'} 🧍 EOA]`;
          fs.appendFileSync(outputPermitFile, permitLine + '\n', 'utf-8');
          console.log(`[💾] Tersimpan di Permit file: ${address}`);
        }
      } else {
        console.log(`[⚠️] Kosong: ${address}`);
      }
    } catch (err) {
      console.log(`[❌] ${address}: ${err.message}`);
    }
  }

  console.log('\n✅ Selesai semua wallet.');
}

main();
